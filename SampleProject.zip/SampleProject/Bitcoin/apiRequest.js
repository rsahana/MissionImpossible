var requestnew = require('request');

var methods = {};

methods.getBitcoins = function(){
						var msg;
						var url = "https://blockchain.info/q/24hrprice";
						requestnew.get( {
						url : url,
						headers : {
						"content-type": "application/json"
						}
						}, function(error, response, body) {
								//console.log("priceHandler response: " + JSON.stringify(response) + " Body: " + body + " | Error: " + error);
						 msg = "Right now the price of a bitcoin is " + body + " USD. What else would you like to know?";
						console.log(msg);											
						} );						
						return msg;
						};
						
exports.functions = methods ;