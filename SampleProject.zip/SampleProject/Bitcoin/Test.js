var request = require('request');
// require basic auth
var auth = require('basic-auth');
let express = require('express');
let bodyParser = require('body-parser');

						var username = "rprep";
						var password = "mi";
						var auth = "Basic " + new Buffer(username + ":" + password).toString("base64");
						var url = "http://localhost/Webforce_7_0_0/v1/Journey_API(55781)";
						console.log("Test");
						request.get( {
						url : url,
						headers : {
						"Authorization" : auth,
						"content-type": "application/json"
						}
						}, function(error, response, body) {
								response.send(body);
						} );
					
