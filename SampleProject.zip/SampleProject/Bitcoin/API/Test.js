var request = require('request');
// require basic auth
var responses = require('./apiRequest.js');

var auth = require('basic-auth');
let express = require('express');
let bodyParser = require('body-parser');
						//
						// var username = "rprep";
						// var password = "mi";
						// var auth = "Basic " + new Buffer(username + ":" + password).toString("base64");
						// var url = "http://localhost/Webforce_7_0_0/v1/Journey_API";
						// console.log("Test");
						// request.post( {
						// url : url,
						// headers : {
						// "Authorization" : auth,
						// "content-type": "application/json"
						// },
						// body: {
						// 	NAME: 'Journey Selvam Testing',
	     		// 		TOPIC_IDENTIFIER: 8,
	     		// 		CLIENT_JOURNEY_IDENTIFIER: '21#JOUR#UK#En-UK' },
	  				// 	json: true
						// }, function(error, response, body) {
						// 		console.log(body);
						// } );
						// var url = "https://blockchain.info/q/24hrprice";
						// requestnew.get( {
						// url : url,
						// headers : {
						// "content-type": "application/json"
						// }
						// }, function(error, response, body) {
						// 		//console.log("priceHandler response: " + JSON.stringify(response) + " Body: " + body + " | Error: " + error);
						// const msg = "Right now the price of a bitcoin is " + body + " USD. What else would you like to know?";
						// console.log(msg);
						// } );
						//
						var value='Spears';
						//
						responses.functions.getCustomerDetails(value,function(result){
							//console.log(result);
							var a = result;
							console.log(a["ID"]);
						});
