var request = require('request');
var methods = {};
var msg;
var username = "rprep";
var password = "mi";
var auth = "Basic " + new Buffer(username + ":" + password).toString("base64");
var server = "http://localhost/Webforce_7_0_0/v1/";

methods.getJourneyName = function(value,callback)
{

						var url = server+"Journey_API("+value+")";
						request.get( {
						url : url,
						headers :
						{
							"Authorization" : auth,
						"content-type": "application/json"
						}
						}, function(error, response, body)
						{
							var myObj = JSON.parse(body);
							var jname = myObj.NAME;
							msg = "Your Journey name for the id "+value+" is "+jname;
							return callback(msg);
						});
};


methods.getCustomerDetails = function(cName,callback)
{
					var customerName = cName.toUpperCase();
					console.log(customerName);
					var customerDetails=[];
					var url = server+"Individual_API?$filter=toupper(FIRST_NAME) eq '"+customerName+"' or toupper(LAST_NAME) eq '"+customerName+"'";
					request.get( {
					url : url,
					headers :
					{
						"Authorization" : auth,
					"content-type": "application/json"
					}
					}, function(error, response, body)
					{
						var contact = JSON.parse(body);
						customerDetails["ID"]=contact.value[0].INDIVIDUAL_IDENTIFIER;
						customerDetails["clientID"]=contact.value[0].CLIENT_INDIVIDUAL_IDENTIFIER;
						return callback(customerDetails);
					});
}

//adding methods to exports to handle in index.js
exports.functions = methods ;
