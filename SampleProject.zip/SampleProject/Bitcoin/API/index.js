'use strict';

process.env.DEBUG = 'actions-on-google:*';

//Define the Googlwe Assitant
var ApiAiAssistant = require ('actions-on-google').ApiAiAssistant;

// require basic auth
var auth = require('basic-auth');

// External api call file
var responses = require('./apiRequest.js');

//Intents
const WELCOMEINTENT = 'input.welcome';
const ORDER_STATUS = 'input.orderid';
const OPTIONINTENT = 'OrderStatus.OrderStatus-fallback';
const CUSTOMERCARD = 'Customer_Details';

//Entities
const ORDERID = 'orderid';
const CCARD = 'customerdetails';


//Agent called from API.AI
exports.agent = function (request, response){

var assistant = new ApiAiAssistant({request: request, response: response});
console.log("Test");

//Handle Welcome Intent
	function WelcomeIntent(assistant) {
		assistant.ask("With EShopping, you can get the product order status");
	}

//Handle OrderStatus Intent
	function trackOrderStatus(assistant) {

	var orderidfromuser = request.body.result.parameters['orderid'];
	//var orderidfromuser = assistant.getArgument(ORDERID);
	var orderStatusMessage = "";

		if (orderidfromuser != "" && orderidfromuser != null)
		{
				// responses.functions.getJourneyName(orderidfromuser,function(result)
				// {
				// 	assistant.ask (result);
				// });



							assistant.askWithList(assistant.buildRichResponse()
									.addSimpleResponse('Alright here your appoinment')
									.addSuggestions(
									['Appoinment', 'List', 'Carousel', 'Suggestions']),
									// Build a list
									assistant.buildList('Things to learn about')
									// Add the first item to the list
									.addItems(assistant.buildOptionItem('MATH_AND_PRIME',
									['math', 'math and prime', 'prime numbers', 'prime'])
									.setTitle('Math & prime numbers')
									.setDescription('42 is an abundant number because the sum of its ' +
									'proper divisors 54 is greater…')
									.setImage('https://assistant.google.com/static/images/molecule/Molecule-Formation-stop.png', 'Math & prime numbers'))
									// Add the second item to the list
									.addItems(assistant.buildOptionItem('EGYPT',
									['religion', 'egpyt', 'ancient egyptian'])
									.setTitle('Ancient Egyptian religion')
									.setDescription('42 gods who ruled on the fate of the dead in the ' +
									'afterworld. Throughout the under…')
									.setImage('https://assistant.google.com/static/images/molecule/Molecule-Formation-stop.png', 'Egypt')
									)
									// Add third item to the list
									.addItems(assistant.buildOptionItem('RECIPES',
									['recipes', 'recipe', '42 recipes'])
									.setTitle('42 recipes with 42 ingredients')
									.setDescription('Here\'s a beautifully simple recipe that\'s full ' +
									'of flavor! All you need is some ginger and…')
									.setImage('https://assistant.google.com/static/images/molecule/Molecule-Formation-stop.png', 'Recipe')
							)
							);
		}
		else
		{
					assistant.ask(orderidfromuser+"please provide valid order id to check your order status");
		}
	}
	function itemSelected (assistant) {
		//assistant.ask("Its Inside");
	  // Get the user's selection
	  const param = assistant.getSelectedOption();
		if (param==null ){
			assistant.ask("Its Inside null");
		}
	  // Compare the user's selections to each of the item's keys
	  if (!param) {
	    assistant.ask('You did not select any item from the list or carousel');
	  } else if (param === 'MATH_AND_PRIME') {
	    assistant.ask('42 is an abundant number because the sum of its…');
	  } else if (param === 'EGYPT') {
	    assistant.ask('42 gods who ruled on the fate of the dead in the '+param);
	  } else if (param === 'RECIPES') {
	    assistant.ask('Here\'s a beautifully simple recipe that\'s full ');
	  } else {
	    assistant.ask('You selected an unknown item from the list or carousel');
	  }
	}

function cutomerCard(assistant)
{
		//let displayName = assistant.getUserName().displayName;
		var customrName =request.body.result.parameters['calldetails'];
		if(customrName !=null && customrName !="")
		{
			responses.functions.getCustomerDetails(customrName,function(result)
			{
						//assistant.ask (result);
						var resultvalues = result;
						assistant.ask(assistant.buildRichResponse()
	// Create a basic card and add it to the rich response

								.addSimpleResponse("Here "+resultvalues["clientID"] +" Details")
								.addSuggestions(
								['Shom me 55781', 'List', 'Carousel'])
								.addBasicCard(assistant.buildBasicCard(`42 is an even composite number. It
									is composed of three dist…`)
									.setTitle(customrName+"("+resultvalues["ID"]+")")
									.setImage('https://assistant.google.com/static/images/molecule/Molecule-Formation-stop.png', 'Customer Card')
									.addButton("Navigate","https://google.com")
								)
							);
			});
		}
		else
		{
			assistant.ask("Hey I need customer name to show you the customer details !!"+customrName);
		}
}

	//Mapping the intent and Handle the request from API.AI
    var actionMap = new Map ();
    actionMap.set(WELCOMEINTENT, WelcomeIntent);
    actionMap.set(ORDER_STATUS, trackOrderStatus);
		actionMap.set(OPTIONINTENT, itemSelected);
		actionMap.set(CUSTOMERCARD,cutomerCard);
    assistant.handleRequest(actionMap);
};
