var request = require('request');
var urlParser = require('url');
var querystring = require("querystring");
var methods = {};
var msg;
var username = "rprep";
var password = "mi";
var auth = "Basic " + new Buffer(username + ":" + password).toString("base64");
var server = "http://10.205.49.38/Webforce_7_0_0/v1/";



			methods.getAppRequest=function (value,callback)
			{
					var filterValue=value;
					var appoinmentsValues=[];
					var customerIDFilter="";
					// var fd ="2016-05-25T05:30:00Z";
					// var td = "2016-05-26T05:30:00Z";
					// var url = server+"Appoinment_API?$filter="+
					//console.log(querystring.unescape(url));
					var options = {
					method: 'GET',
					url: server+"Appointment_API?$filter="+filterValue,
					// qs: { '$filter': filterValue },
					headers:
					{
					'cache-control': 'no-cache',
					authorization: auth }
					};

					request(options, function (error, response, body) {
					if (error) throw new Error(error);
           var appointments = JSON.parse(body);
					 appointments.value.forEach(function(item,index){
						 var appointment= {
							  "ID"	:	item.EMPLOYEE_ID,
								"CUSTOMERID"	:	item.CUSTOMER_ID,
								"CUSTOMERNAME"	:  ""	,
								"STARTDATETIME"	:	item.START_DATE_TIME,
								"ENDDATETIME"	:	item.END_DATE_TIME,
								"APPOINTMENTID":item.APPOINTMENT_IDENTIFIER
							};
							customerIDFilter+="(INDIVIDUAL_IDENTIFIER eq "+item.CUSTOMER_ID+")";
							if(index<appointments.value.length-1)
								customerIDFilter+=" or ";
						 appoinmentsValues.push(appointment);
					 });


						var options = {
						method: 'GET',
						url: server+"Individual_API?$select = CLIENT_INDIVIDUAL_IDENTIFIER,INDIVIDUAL_IDENTIFIER&$filter="+customerIDFilter,
						// qs: { '$filter': filterValue },
						headers:
						{
							'cache-control': 'no-cache',
							authorization: auth }
						};

						// var customers;
						request(options, function (error, response, body) {
							var newAppointmentValues=[];
									if (error) throw new Error(error);
									 var customers = JSON.parse(body);

									 	 customers.value.forEach(function(customer,index){
			 									 var obj=appoinmentsValues.find(function(obj){
			 										 return obj.CUSTOMERID==customer.INDIVIDUAL_IDENTIFIER;
			 									 });
			 									 //console.log(customer);

			 									 obj["CUSTOMERNAME"]=customer.CLIENT_INDIVIDUAL_IDENTIFIER;
												 //  console.log(obj);
			 									 newAppointmentValues.push(obj);
			 									 //console.log(newAppointmentValues);
			 									 // console.log(appoinmentsValues);
			 							 });
											// 	console.log(newAppointmentValues);
			 					 return callback(newAppointmentValues);
						});
						// console.log(customers);


				});
			}


methods.createAppointment = function(cusName,startDate,callback)
{
					var customerID;
					var customerName = cusName.toUpperCase();
					var options =
					{
					method: 'GET',
					url: server+"Individual_API?$filter=toupper(FIRST_NAME) eq '"+customerName+"' or toupper(LAST_NAME) eq '"+customerName+"' or CLIENT_INDIVIDUAL_IDENTIFIER eq '"+customerName+"' "+"& $select=INDIVIDUAL_IDENTIFIER",
					headers:
					{
					'cache-control': 'no-cache',
					authorization: auth
					}
					};

					request(options, function (error, response, body)
					{
						if (error) throw new Error(error);
							var values = JSON.parse(body);
							var cid = values.value;
							customerID = cid[0].INDIVIDUAL_IDENTIFIER;
							//console.log(customerID);

							var options1 = {
							method: 'POST',
							url: server+'Appointment_API',
							headers:
							{
							'cache-control': 'no-cache',
							'content-type': 'application/json',
							authorization: auth
							},
							body:
							{
									EMPLOYEE_ID: 70000000000283,
									AffiliationId: 70000000008275,
									CUSTOMER_ID: customerID,
									START_DATE_TIME: startDate,
									// END_DATE_TIME:'' ,
									SamplesDocumentId: 'A',
									EVENT_SUB_TYPE: 'GA',
									EVENT_TYPE: 'A',
									STATUS: 'OPEN',
									STATUS_CHANGE_DATE: '2017-09-07T12:25:27Z'
							},
							json: true
							};

							request(options1, function (error1, response1, body1) {
							if (error1) throw new Error(error1);
							//console.log(body1);
									var appoinmentID = body1.APPOINTMENT_IDENTIFIER;
									//console.log(appoinmentID);
									return callback(appoinmentID);
							});
					});
}

methods.getAppDeleteRequestCustomer = function(cusName,callback)
{
					var customerID;
					var customerName = cusName.toUpperCase();
					var appoinmentsValues=[];
					var options =
					{
					method: 'GET',
					url: server+"Individual_API?$filter=toupper(FIRST_NAME) eq '"+customerName+"' or toupper(LAST_NAME) eq '"+customerName+"' or CLIENT_INDIVIDUAL_IDENTIFIER eq '"+customerName+"' "+"& $select=INDIVIDUAL_IDENTIFIER",
					headers:
					{
					'cache-control': 'no-cache',
					authorization: auth
					}
					};

					request(options, function (error, response, body)
					{
						if (error) throw new Error(error);

											var values = JSON.parse(body);
											var cid = values.value;
											customerID = cid[0].INDIVIDUAL_IDENTIFIER;
											var options1 =
											{
											method: 'GET',
											url: server+'Appointment_API?$filter= CUSTOMER_ID eq '+customerID+'& $select=EMPLOYEE_ID,CUSTOMER_ID,START_DATE_TIME,END_DATE_TIME,APPOINTMENT_IDENTIFIER',
											headers:
											{
											'cache-control': 'no-cache',
											'content-type': 'application/json',
											authorization: auth
											},
											};
											request(options1, function (error1, response1, body1)
											{
													if (error1) throw new Error(error1);
													var appointments = JSON.parse(body1);
													// console.log(appointments);
													appointments.value.forEach(function(item,index)
													{
																var appointment=
																{
																	"ID"	:	item.EMPLOYEE_ID,
																	"CUSTOMERID"	:	item.CUSTOMER_ID,
																	"CUSTOMERNAME"	:  ""	,
																	"STARTDATETIME"	:	item.START_DATE_TIME,
																	"ENDDATETIME"	:	item.END_DATE_TIME,
																	"APPOINTMENTID":item.APPOINTMENT_IDENTIFIER
																};
																appoinmentsValues.push(appointment);
													});
											return callback(appoinmentsValues);
											});
					});
}

methods.deleteAppointment = function (appID,callback)
{
						var appointmentID = appID;
						var options =
						{
						method: 'DELETE',
						url: server+'Appointment_API('+appointmentID+')',
						headers:
						{
						'cache-control': 'no-cache',
						authorization: auth
						}
						};

						request(options, function (error, response, body)
						{
								if (error) throw new Error(error);
								console.log(body);
								return callback("success");
						});
}


methods.getCustomerDetails = function(customrName,callback)
{
					var customerID;
					var customerName = customrName.toUpperCase();
					var options =
					{
					method: 'GET',
					url: server+"Individual_API?$filter=toupper(FIRST_NAME) eq '"+customerName+"' or toupper(LAST_NAME) eq '"+customerName+"' or toupper(CLIENT_INDIVIDUAL_IDENTIFIER) eq '"+customerName+"' "+"& $select=INDIVIDUAL_IDENTIFIER,CLIENT_INDIVIDUAL_IDENTIFIER"
					+"&$expand=IndividualAffiliation_API($filter=AFF_PRIMARY_FLAG eq true;$select=ADDRESS_IDENTIFIER)",
					headers:
					{
					// 'cache-control': 'no-cache',
					authorization: auth
					}
					};
					var customerDetails=[];
					var addressIdc="";
					request(options, function (error, response, body)
					{
					  if (error) throw new Error(error);
							var customers=JSON.parse(body);
							customers.value.forEach(function(customer,index)
							{
								var customerName=customer.CLIENT_INDIVIDUAL_IDENTIFIER;
								var customerID = customer.INDIVIDUAL_IDENTIFIER;
								var affiliation=customer.IndividualAffiliation_API;
								var addressId=affiliation[0].ADDRESS_IDENTIFIER;
								var customerDetail={"CUSTOMERNAME":customerName,"ADDRESSID":addressId,"CUSTOMERID":customerID};
								customerDetails.push(customerDetail);

								addressIdc+="(ADDRESS_IDENTIFIER eq "+addressId+")";
								if(index<customers.value.length-1)
									addressIdc+=" or ";
							});
							// console.log(addressIdc);
							var addressForCustomer =[];
							var options1 =
							{
							method: 'GET',
							url: server+'Address_API?$filter='+addressIdc+'&$select=LINE_1_ADDRESS,VILLAGE_LABEL,POST_CODE,LATITUDE,LONGITUDE,COUNTRY_CODE,ADDRESS_IDENTIFIER',
							headers:
							{
							// 'cache-control': 'no-cache',
							'content-type': 'application/json',
							authorization: auth
							},
							};
							request(options1, function (error1, response1, body1)
							{
									if (error1) throw new Error(error1);
									var addresses = JSON.parse(body1);
									// console.log(appointments);
									addresses.value.forEach(function(item,index)
									{
										var obj=customerDetails.find(function(obj){
											return obj.ADDRESSID==item.ADDRESS_IDENTIFIER;
										});
										//console.log(obj);
												var addresseFound=
												{
														"LINE_1_ADDRESS": item.LINE_1_ADDRESS,
														"VILLAGE_LABEL": item.VILLAGE_LABEL,
														"POST_CODE": item.POST_CODE,
														"LATITUDE": item.LATITUDE,
														"LONGITUDE": item.LONGITUDE,
														"COUNTRY_CODE": item.COUNTRY_CODE,
														"ADDRESS_IDENTIFIER": item.ADDRESS_IDENTIFIER,
														"CUSTOMERNAME":obj.CUSTOMERNAME,
														"CUSTOMERID":obj.CUSTOMERID
												};
												addressForCustomer.push(addresseFound);
									});
									return callback(addressForCustomer);
							});
					});
}

methods.getLastCallDetails=function(cusName,callback)
{
					var customerID;
					var customerName = cusName.toUpperCase();
					var options =
					{
					method: 'GET',
					url: server+"Individual_API?$filter=toupper(FIRST_NAME) eq '"+customerName+"' or toupper(LAST_NAME) eq '"+customerName+"' or CLIENT_INDIVIDUAL_IDENTIFIER eq '"+customerName+"' "+"& $select=INDIVIDUAL_IDENTIFIER",
					headers:
					{
					'cache-control': 'no-cache',
					authorization: auth
					}
					};

					request(options, function (error, response, body)
					{
						var values = JSON.parse(body);
						var cid = values.value;
						customerID = cid[0].INDIVIDUAL_IDENTIFIER;
						var options1 =
						{
						method: 'GET',
						url: server+'Call_API?$filter= (CUSTOMER_IDENTIFIER eq '+customerID+')&$orderby=CALL_DATE desc&$select=CALL_DATE',
						headers:
						{
						'cache-control': 'no-cache',
						'content-type': 'application/json',
						authorization: auth
						},
						};
						request(options1, function (error1, response1, body1)
						{
								if (error1) throw new Error(error1);
								var datas = JSON.parse(body1);
								console.log(datas.value[0].CALL_DATE);
								var dateTime = datas.value[0].CALL_DATE;
								// console.log(dateTime);
						return callback(dateTime);
						});

					});
}


methods.getLastcallPeriods = function(cusName,fromDate,toDate,callback)
{
							var customerID;
							var customerName = cusName.toUpperCase();
							var options =
							{
							method: 'GET',
							url: server+"Individual_API?$filter=toupper(FIRST_NAME) eq '"+customerName+"' or toupper(LAST_NAME) eq '"+customerName+"' or CLIENT_INDIVIDUAL_IDENTIFIER eq '"+customerName+"' "+"& $select=INDIVIDUAL_IDENTIFIER",
							headers:
							{
							'cache-control': 'no-cache',
							authorization: auth
							}
							};

							request(options, function (error, response, body)
							{
								var values = JSON.parse(body);
								var cid = values.value;
								customerID = cid[0].INDIVIDUAL_IDENTIFIER;
								var options1 =
								{
								method: 'GET',
								url: server+'Call_API?$count=true & $top=0 & $filter=(CALL_DATE gt '+fromDate+' and CALL_DATE lt '+toDate+' and CUSTOMER_IDENTIFIER eq '+customerID+')& $select=CUSTOMER_IDENTIFIER',
								headers:
								{
								'cache-control': 'no-cache',
								'content-type': 'application/json',
								authorization: auth
								},
								};
								request(options1, function (error1, response1, body1)
								{
										if (error1) throw new Error(error1);
										var datas = JSON.parse(body1);
										var count = datas["@odata.count"];
										console.log(count);

										return callback(count);
								});

							});
}

methods.getLastcallPeriodDates = function(fromDate,toDate,callback)
{

							var options =
							{
							method: 'GET',
							url: server+'Call_API?$count=true & $top=0 & $filter=(CALL_DATE gt '+fromDate+' and CALL_DATE lt '+toDate+')& $select=CUSTOMER_IDENTIFIER',
							headers:
							{
							'cache-control': 'no-cache',
							authorization: auth
							}
							};

							request(options, function (error, response, body)
							{
									var values = JSON.parse(body);
										if (error) throw new Error(error);
										var count = values["@odata.count"];
										console.log(count);
										return callback(count);
							});
}


methods.getDateNotifications = function(date,callback)
{
						var options =
						{
						method: 'GET',
						url: server+'HomePage_Message_API?$filter=STATUS eq '+"'ACTV'"+' and CREATE_DATE eq '+date+'& $select=MESSAGE_TEXT,MESSAGE_TYPE',
						headers:
						{
						'cache-control': 'no-cache',
						authorization: auth
						}
						};

						request(options, function (error, response, body)
						{
							var notifications = [];
								var values = JSON.parse(body);
								console.log(values);
									if (error) throw new Error(error);
									values.value.forEach(function(item,index)
									{
												notifications.push(item);
									});
									return callback(notifications);
						});
}



//adding methods to exports to handle in index.js
exports.functions = methods ;
