var request = require('request');
// require basic auth
var responses = require('./apiRequest.js');
var helper = require('./apiHelper.js');
var auth = require('basic-auth');
						//
						// var username = "rprep";
						// var password = "mi";
						// var auth = "Basic " + new Buffer(username + ":" + password).toString("base64");
						// var url = "http://localhost/Webforce_7_0_0/v1/Journey_API";
						// console.log("Test");
						// request.post( {
						// url : url,
						// headers : {
						// "Authorization" : auth,
						// "content-type": "application/json"
						// },
						// body: {
						// 	NAME: 'Journey Selvam Testing',
	     		// 		TOPIC_IDENTIFIER: 8,
	     		// 		CLIENT_JOURNEY_IDENTIFIER: '21#JOUR#UK#En-UK' },
	  				// 	json: true
						// }, function(error, response, body) {
						// 		console.log(body);
						// } );
						// var url = "https://blockchain.info/q/24hrprice";
						// requestnew.get( {
						// url : url,
						// headers : {
						// "content-type": "application/json"
						// }
						// }, function(error, response, body) {
						// 		//console.log("priceHandler response: " + JSON.stringify(response) + " Body: " + body + " | Error: " + error);
						// const msg = "Right now the price of a bitcoin is " + body + " USD. What else would you like to know?";
						// console.log(msg);
						// } );
						//
						// var value='Spears';
						// //
						// responses.functions.getCustomerDetails(value,function(result){
						// 	//console.log(result);
						// 	var a = result;
						// 	console.log(a["ID"]);
						// });
// var date = "2017-09-06";
// var date2= new Date(date);
// console.log(date2);
// var date1 = new Date(date2.setTime( date2.getTime() + 1 * 86400000 ));
// console.log(date1);
						// responses.functions.getMap(function(result)
						// {
						// 	console.log (result);
						// });
// var one="2016-05-26T00:00:00Z";
// var two = "2016-05-26T03:03:00Z";
// // var date = one +"/"+two;
// var date = "2017-09-07";
// var filterValue;
// if(date.indexOf("/") !== -1)
// {
// 		var dates = date.split("/");
// 		var fromDate = dates[0];
// 		var toDate = dates[1];
// 		filterValue = "(START_DATE_TIME gt "+fromDate +") and (START_DATE_TIME lt "+toDate+")";
// }
// else
// {
//
// 			var dateFrom = new Date(date);
// 			var dateTo;
// 			helper.helperFunctions.addDays(date,0,function(result)
// 			{
// 					dateFrom = result;
// 			});
// 			helper.helperFunctions.addDays(date,1,function(result)
// 			{
// 					dateTo = result;
// 			});
// 			filterValue = "(START_DATE_TIME gt "+dateFrom +") and (START_DATE_TIME lt "+dateTo+")";
// }
var name ='Spears';
var filterValue = '2017-09-07';
var time ='12:25:27';
var date = filterValue+"T"+time+"Z";
//
//
// var date = new Date(date);
// var options = {
// 	hour: 'numeric',
// 	minute: 'numeric',
// 	hour12: true
// };
// var timeString = date.toLocaleString('en-US', options);

// var date = "2017-09-09";

var values = date.split('/');

var cusname = "cooper";

responses.functions.createAppointment(name,date,function(result)
{
			// var count =result;
			// console.log("You have done "+count+" calls for in the period from "+values[0]+" to "+values[1]+" ");
			console.log(result);
});

// var base = "assistant.buildRichResponse().addSimpleResponse('Alright here your appoinment').addSuggestions("
// 	+"['Appoinment', 'List', 'Carousel', 'Suggestions']),"
// 	+"assistant.buildList('Things to learn about')";
// 		for(var i=0;i<3;i++)
// 				{
// 								base += ".addItems(assistant.buildOptionItem('MATH_AND_PRIME',"
// 									+"['math, 'math and prime', 'prime numbers', 'prime'])"
// 									+".setTitle('Math & prime numbers')"
// 									+".setDescription('Show me 55781')"
// 									+".setImage('https://assistant.google.com/static/images/molecule/Molecule-Formation-stop.png', 'Math & prime numbers')"
// 									+")"
// 				}
// console.log(base);
