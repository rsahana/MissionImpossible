var request = require('request');
// require basic auth
var responses = require('./apiRequest.js');
var helper = require('./apiHelper.js');
var auth = require('basic-auth');
var storage = require('node-persist');
var geoip = require('./geoip');



var date = "2017-09-17T00:00:00Z";
// var dateFrom = new Date(date);
var dateTo;
// helper.helperFunctions.addDays(date,0,function(result)
// {
//     dateFrom = result;
// });
// helper.helperFunctions.addDays(date,1,function(result)
// {
//     dateTo = result;
// });
// filterValue = "(START_DATE_TIME gt "+dateFrom +") and (START_DATE_TIME lt "+dateTo+")";
// console.log(filterValue);
// filterValue = "Copper's";
// responses.functions.getDateNotifications(date,function(result)
// {
// 			// var count =result;
// 			// console.log("You have done "+count+" calls for in the period from "+values[0]+" to "+values[1]+" ");
// 			console.log(result);
// });

// var base = "assistant.buildRichResponse().addSimpleResponse('Alright here your appoinment').addSuggestions("
// 	+"['Appoinment', 'List', 'Carousel', 'Suggestions']),"
// 	+"assistant.buildList('Things to learn about')";
// 		for(var i=0;i<3;i++)
// 				{
// 								base += ".addItems(assistant.buildOptionItem('MATH_AND_PRIME',"
// 									+"['math, 'math and prime', 'prime numbers', 'prime'])"
// 									+".setTitle('Math & prime numbers')"
// 									+".setDescription('Show me 55781')"
// 									+".setImage('https://assistant.google.com/static/images/molecule/Molecule-Formation-stop.png', 'Math & prime numbers')"
// 									+")"
// 				}
// console.log(base);
// var cusName = request.headers['x-forwarded-for'];
/**
 * Get the user IP throught the webkitRTCPeerConnection
 * @param onNewIP {Function} listener function to expose the IP locally
 * @return undefined
 */
function getUserIP(onNewIP) { //  onNewIp - your listener function for new IPs
    //compatibility for firefox and chrome
    var myPeerConnection = window.RTCPeerConnection || window.mozRTCPeerConnection || window.webkitRTCPeerConnection;
    var pc = new myPeerConnection({
        iceServers: []
    }),
    noop = function() {},
    localIPs = {},
    ipRegex = /([0-9]{1,3}(\.[0-9]{1,3}){3}|[a-f0-9]{1,4}(:[a-f0-9]{1,4}){7})/g,
    key;

    function iterateIP(ip) {
        if (!localIPs[ip]) onNewIP(ip);
        localIPs[ip] = true;
    }

     //create a bogus data channel
    pc.createDataChannel("");

    // create offer and set local description
    pc.createOffer().then(function(sdp) {
        sdp.sdp.split('\n').forEach(function(line) {
            if (line.indexOf('candidate') < 0) return;
            line.match(ipRegex).forEach(iterateIP);
        });

        pc.setLocalDescription(sdp, noop, noop);
    }).catch(function(reason) {
        // An error occurred, so handle the failure to connect
    });

    //listen for candidate events
    pc.onicecandidate = function(ice) {
        if (!ice || !ice.candidate || !ice.candidate.candidate || !ice.candidate.candidate.match(ipRegex)) return;
        ice.candidate.candidate.match(ipRegex).forEach(iterateIP);
    };
}

// Usage

getUserIP(function(ip){
    console.log("Got IP! :" + ip);
});


storage.initSync();

//then start using it
storage.setItemSync('name','Selvam');
console.log(storage.getItemSync('name'));
