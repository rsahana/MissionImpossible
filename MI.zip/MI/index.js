'use strict';

process.env.DEBUG = 'actions-on-google:*';

//Define the Googlwe Assitant
var ApiAiAssistant = require ('actions-on-google').ApiAiAssistant;

// require basic auth
var auth = require('basic-auth');

// External api call file
var responses = require('./apiRequest.js');
var helper = require('./apiHelper.js');
//Intents
const WELCOMEINTENT = 'input.welcome';
const PERMISSION = 'welcomeintent.permission.fallback';
const GETAPPOINMENT ='get.appointment';
const GETAPPOINTMENTFALLBACK='GetAppointment.GetAppointment-fallback';
const DELETEAPPOINTMENT ='input.delete.appointment';
const DELETEFALLBACK ='delete_appointment.delete_appointment-fallback';
const CREATEAPPOINTMENT='input.create.appointment';

//Entities
const STARTDATE = 'startdate';
const CCARD = 'customerdetails';

//Global variable
let displayName;
let devicLatitude;
let devicelongitude;
//Agent called from API.AI
exports.miagent = function (request, response){

var assistant = new ApiAiAssistant({request: request, response: response});

//permission
let namePermission = assistant.SupportedPermissions.NAME;
let preciseLocationPermission = assistant.SupportedPermissions.DEVICE_PRECISE_LOCATION;

//Handle Welcome Intent
function WelcomeIntent(assistant)
{
	assistant.askForPermissions('To address you by name and know your location',[namePermission, preciseLocationPermission]);
}

function handlePermission(assistant)
{
	if (assistant.isPermissionGranted())
	{
		displayName = assistant.getUserName().displayName;
		devicLatitude = assistant.getDeviceLocation().coordinates.latitude;
		devicelongitude =  assistant.getDeviceLocation().coordinates.longitude;
		assistant.ask("Hi "+displayName+" How can I help you?");
	}
	else
	{
		assistant.ask("Hi, How can I help you?");
	}
}

function getAppointments(assistant)
{
			var date = request.body.result.parameters['startdate'];
			var filterValue;
			if(date.indexOf("/") !== -1)
			{
					var dates = date.split("/");
					var fromDate = dates[0];
					var toDate = dates[1];
					filterValue = "(START_DATE_TIME gt "+fromDate +") and (START_DATE_TIME lt "+toDate+")";
			}
			else
			{

						var dateFrom = new Date(date);
						var dateTo;
						helper.helperFunctions.addDays(date,0,function(result)
						{
								dateFrom = result;
						});
						helper.helperFunctions.addDays(date,1,function(result)
						{
								dateTo = result;
						});
						filterValue = "(START_DATE_TIME gt "+dateFrom +") and (START_DATE_TIME lt "+dateTo+")";
			}

			//TO DO Card building
  		if(filterValue!=null && filterValue!="")
			{
					responses.functions.getAppRequest(filterValue,function(result)
					{
						var values =result;
						if(values!=null && values.length>0){

									switch (values.length)
									{

										case 1:
														{
															assistant.ask(assistant.buildRichResponse()
															.addSimpleResponse("Here you Go")
															.addSuggestions(
															['Show me', 'List', 'Carousel'])
															.addBasicCard(assistant.buildBasicCard("Your Appoinment starts at "+values[0]["STARTDATETIME"]+" and ends at"+values[0]["ENDDATETIME"])
															.setTitle("Appoinment "+values[0]["CUSTOMERNAME"])
															.setImage('http://ignitewoo.com/wp-content/uploads/2013/09/wocommerce-event-calendar-ticketing-pro.png', '')
															.addButton("Navigate to customer","https://www.google.co.in/maps/dir/12.9353018,77.6940171/12.9135223,77.6038353")
															)
															);
															break;
														}
										case 2:
										{
															assistant.askWithList(assistant.buildRichResponse()
                             .addSimpleResponse('Alright here your appoinment')
                             .addSuggestions(
                             ['Appoinment', 'List', 'Carousel', 'Suggestions']),
                             // Build a list
                             assistant.buildList('Things to learn about'+date)
                             // Add the first item to the list
														 .addItems(assistant.buildOptionItem(values[0]["APPOINTMENTID"]+"_"+values[0]["CUSTOMERID"]+"_"+values[0]["STARTDATETIME"]+"_"+values[0]["ENDDATETIME"]+"_"+values[0]["CUSTOMERNAME"],
														 ['math', 'math and prime', 'prime numbers', 'prime'])
														 .setTitle("Appoinment "+values[0]["CUSTOMERNAME"])
														 .setDescription("Your Appoinment starts at "+values[0]["STARTDATETIME"]+" and ends at"+values[0]["ENDDATETIME"])
														 .setImage('http://ignitewoo.com/wp-content/uploads/2013/09/wocommerce-event-calendar-ticketing-pro.png', 'Math & prime numbers'))
														 // Add the second item to the list
														 .addItems(assistant.buildOptionItem(values[1]["APPOINTMENTID"]+"_"+values[1]["CUSTOMERID"]+"_"+values[1]["STARTDATETIME"]+"_"+values[1]["ENDDATETIME"]+"_"+values[1]["CUSTOMERNAME"],
															['religion', 'egpyt', 'ancient egyptian'])
														 .setTitle("Appoinment "+values[1]["CUSTOMERNAME"])
														 .setDescription("Your Appoinment starts at "+values[1]["STARTDATETIME"]+" and ends at"+values[1]["ENDDATETIME"])
														 .setImage('http://ignitewoo.com/wp-content/uploads/2013/09/wocommerce-event-calendar-ticketing-pro.png', 'Math & prime numbers'))

															);
															break;
										}

										default:
										{
															assistant.askWithList(assistant.buildRichResponse()
														 .addSimpleResponse('Alright here your appoinment')
														 .addSuggestions(
														 ['Appoinment', 'List', 'Carousel', 'Suggestions']),
														 // Build a list
														 assistant.buildList('You Appoinments for '+date)
														 // Add the first item to the list
														 .addItems(assistant.buildOptionItem(values[0]["APPOINTMENTID"]+"_"+values[0]["CUSTOMERID"]+"_"+values[0]["STARTDATETIME"]+"_"+values[0]["ENDDATETIME"]+"_"+values[0]["CUSTOMERNAME"],
														 ['math', 'math and prime', 'prime numbers', 'prime'])
														 .setTitle("Appoinment "+values[0]["CUSTOMERNAME"])
														 .setDescription("Your Appoinment starts at "+values[0]["STARTDATETIME"]+" and ends at"+values[0]["ENDDATETIME"])
														 .setImage('http://ignitewoo.com/wp-content/uploads/2013/09/wocommerce-event-calendar-ticketing-pro.png', 'Math & prime numbers'))
														 // Add the second item to the list
														 .addItems(assistant.buildOptionItem(values[1]["APPOINTMENTID"]+"_"+values[1]["CUSTOMERID"]+"_"+values[1]["STARTDATETIME"]+"_"+values[1]["ENDDATETIME"]+"_"+values[1]["CUSTOMERNAME"],
															['religion', 'egpyt', 'ancient egyptian'])
														 .setTitle("Appoinment "+values[1]["CUSTOMERNAME"])
														 .setDescription("Your Appoinment starts at "+values[1]["STARTDATETIME"]+" and ends at"+values[1]["ENDDATETIME"])
														 .setImage('http://ignitewoo.com/wp-content/uploads/2013/09/wocommerce-event-calendar-ticketing-pro.png', 'Math & prime numbers'))

														 .addItems(assistant.buildOptionItem(values[2]["APPOINTMENTID"]+"_"+values[2]["CUSTOMERID"]+"_"+values[2]["STARTDATETIME"]+"_"+values[2]["ENDDATETIME"]+"_"+values[2]["CUSTOMERNAME"],
															['religion', 'egpyt', 'ancient egyptian'])
														 .setTitle("Appoinment "+values[2]["CUSTOMERNAME"])
														 .setDescription("Your Appoinment starts at "+values[1]["STARTDATETIME"]+" and ends at"+values[2]["ENDDATETIME"])
														 .setImage('http://ignitewoo.com/wp-content/uploads/2013/09/wocommerce-event-calendar-ticketing-pro.png', 'Math & prime numbers'))

													 	);
											break;
										}

									}

						}
						else {
							assistant.ask("You don't have any appointments for the "+date);
						}
					});
			}

}

function	getAppointmentSelected(assistant)
{
		const selectedOption=assistant.getSelectedOption();
		if(selectedOption!=null)
		{
				var values=selectedOption.split('_');
				assistant.ask(assistant.buildRichResponse()
				.addSimpleResponse("Here you Go")
				.addSuggestions(
				['todays appointments', values[1], values[2],values[3],values[4]])
				.addBasicCard(assistant.buildBasicCard("Your Appoinment starts at "+values[2]+" and ends at"+values[3])
				.setTitle("Appoinment for "+values[4])
				.setImage('http://ignitewoo.com/wp-content/uploads/2013/09/wocommerce-event-calendar-ticketing-pro.png', 'Appoinment')
				.addButton("Navigate to customer","https://www.google.co.in/maps/dir/12.9353018,77.6940171/12.9135223,77.6038353")
				)
				);
		}
		else
		{
				assistant.ask("Please select proper option");
		}
}

function createAppointmentForCustomer(assistant)
{
	var appCName = request.body.result.parameters['customername'];
	var appDate = request.body.result.parameters['appointmentdate'];
	var appTime = request.body.result.parameters['appointmenttime'];

			responses.functions.createAppointment(appCName,appDat,function(result)
			{
				var value =result;

				if(value!="" && value !=null)
				{
					assistant.ask(assistant.buildRichResponse()
					.addSimpleResponse("your appoinment for "+appCName+" created successfully")
					.addSuggestions(
					["Update Appoinment","Delete Appoinment"])
					.addBasicCard(assistant.buildBasicCard("Your Appoinment starts at "+appTime+" on "+appDate)
					.setTitle(appCName)
					.setImage('https://www.privoz.pl/assets/templates/privoz/images/uslugi/calendar-1.png', 'Appoinment')
					.addButton("Navigate to customer","https://www.google.co.in/maps/dir/12.9353018,77.6940171/12.9135223,77.6038353")
					)
					);
				}
				else
				{
					assistant.ask("Sorry , i can't create appoinment at this moment try gain later! you can ask me to show todays appoinment.");
				}

			});
//assistant.ask('Hey Your appoinment is created successfully for ' +appCName +" on "+ appDate +" at "+appTime);
}

function deleteAppointment(assistant)
{
			var custNameDelete = request.body.result.parameters['customername'];
			if(custNameDelete!=null && custNameDelete!="")
			{
					responses.functions.getAppDeleteRequestCustomer(custNameDelete,function(result)
					{
						var values =result;
						if(values!=null && values.length>0){

									switch (values.length)
									{

										case 1:
														{
															assistant.ask(assistant.buildRichResponse()
															.addSimpleResponse("Here you Go")
															.addSuggestions(
															['Show me', 'List', 'Carousel'])
															.addBasicCard(assistant.buildBasicCard("This Appoinment starts at "+values[0]["STARTDATETIME"])
															.setTitle(custNameDelete)
															.setImage('http://ignitewoo.com/wp-content/uploads/2013/09/wocommerce-event-calendar-ticketing-pro.png', 'Appoinment')
															.addButton("Navigate to customer","https://www.google.co.in/maps/dir/12.9353018,77.6940171/12.9135223,77.6038353")
															)
															);
															break;
														}
										case 2:
										{
															assistant.askWithList(assistant.buildRichResponse()
														 .addSimpleResponse('Alright here your appoinment')
														 .addSuggestions(
														 ['Appoinment', 'List', 'Carousel', 'Suggestions']),
														 // Build a list
														 assistant.buildList('Appoinment of '+custNameDelete)
														 // Add the first item to the list
														 .addItems(assistant.buildOptionItem(values[0]["APPOINTMENTID"]+"_"+custNameDelete+"_"+values[1]["STARTDATETIME"],
														 ['math', 'math and prime', 'prime numbers', 'prime'])
														 .setTitle("Appoinment 1: "+custNameDelete)
														 .setDescription("This Appoinment starts at "+values[0]["STARTDATETIME"])
														 .setImage('http://ignitewoo.com/wp-content/uploads/2013/09/wocommerce-event-calendar-ticketing-pro.png', 'Appoinment'))
														 // Add the second item to the list
														 .addItems(assistant.buildOptionItem(values[1]["APPOINTMENTID"]+"_"+custNameDelete+"_"+values[2]["STARTDATETIME"],
														 ['religion', 'egpyt', 'ancient egyptian'])
														 .setTitle("Appoinment 2: "+custNameDelete)
														 .setDescription("This Appoinment starts at "+values[1]["STARTDATETIME"])
														 .setImage('http://ignitewoo.com/wp-content/uploads/2013/09/wocommerce-event-calendar-ticketing-pro.png', 'Appoinment')
														 	)
															);
															break;
										}

										default:
										{

											assistant.askWithList(assistant.buildRichResponse()
													.addSimpleResponse('Alright here your appoinment')
													.addSuggestions(
													['Appoinment', 'List', 'Carousel', 'Suggestions']),
													// Build a list
													assistant.buildList('Appoinment of '+custNameDelete)
													// Add the first item to the list
													.addItems(assistant.buildOptionItem(values[0]["APPOINTMENTID"]+"_"+custNameDelete+"_"+values[0]["STARTDATETIME"],
													['math', 'math and prime', 'prime numbers', 'prime'])
													.setTitle("Appoinment 1: "+custNameDelete)
													.setDescription("This Appoinment starts at "+values[0]["STARTDATETIME"])
													.setImage('http://ignitewoo.com/wp-content/uploads/2013/09/wocommerce-event-calendar-ticketing-pro.png', 'Appoinment'))
													// Add the second item to the list
													.addItems(assistant.buildOptionItem(values[1]["APPOINTMENTID"]+"_"+custNameDelete+"_"+values[1]["STARTDATETIME"],
													['religion', 'egpyt', 'ancient egyptian'])
													.setTitle("Appoinment 2: "+custNameDelete)
													.setDescription("This Appoinment starts at "+values[1]["STARTDATETIME"])
													.setImage('http://ignitewoo.com/wp-content/uploads/2013/09/wocommerce-event-calendar-ticketing-pro.png', 'Appoinment')
													)
													// Add third item to the list
													.addItems(assistant.buildOptionItem(values[2]["APPOINTMENTID"]+"_"+custNameDelete+"_"+values[2]["STARTDATETIME"],
													['recipes', 'recipe', '42 recipes'])
													.setTitle("Appoinment 3: "+custNameDelete)
													.setDescription("This Appoinment starts at "+values[2]["STARTDATETIME"])
													.setImage('http://ignitewoo.com/wp-content/uploads/2013/09/wocommerce-event-calendar-ticketing-pro.png', 'Appoinment')
											)
											);
											break;
										}

									}

						}
						else
						{
							assistant.ask("You don't have any appointments for the customer "+custNameDelete);
						}
					});
			}

}

function	getAppointmentDeleteSelected(assistant)
{
		const selectedOption=assistant.getSelectedOption();
		if(selectedOption!=null)
		{
				var values=selectedOption.split('_');
				var appID = values[0];
				responses.functions.deleteAppointment(appID,function(result)
				{
							if(result=="success" && result!=null)
							{

												assistant.ask(assistant.buildRichResponse()
												.addSimpleResponse("Hey!! Your appointment has been successfully deleted")
												.addSuggestions(
												['todays appointments', values[0], values[1]])
												.addBasicCard(assistant.buildBasicCard("Appoinment Date "+values[2])
												.setTitle("Deleted Appoinment for "+values[1])
												.setImage('http://ignitewoo.com/wp-content/uploads/2013/09/wocommerce-event-calendar-ticketing-pro.png', 'Appoinment')
												)
												);
							}
							else
							{
										assistant.ask("Sorry , i can't delete appoinment at this moment try gain later! you can ask me to show today's appoinment.");
							}
				});
		}
		else
		{
				assistant.ask("Please select proper option");
		}
}






//Handle MI Intent
	//Mapping the intent and Handle the request from API.AI
    var actionMap = new Map ();
    actionMap.set(WELCOMEINTENT, WelcomeIntent);
		actionMap.set(PERMISSION,handlePermission);
		actionMap.set(GETAPPOINMENT,getAppointments);
		actionMap.set(GETAPPOINTMENTFALLBACK,getAppointmentSelected);
		actionMap.set(CREATEAPPOINTMENT,createAppointmentForCustomer);
		actionMap.set(DELETEAPPOINTMENT,deleteAppointment);
		actionMap.set(DELETEFALLBACK,getAppointmentDeleteSelected);
    assistant.handleRequest(actionMap);
};
