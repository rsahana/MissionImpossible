var helperMethods = {};

helperMethods.getUTCDateTime = function(value,callback)
{
  // var datetime = new Date();

  if( value!=null && value !="" )
    var  datetime = new Date(value);

      return callback(datetime);
};

helperMethods.addDays = function(datefrom,days,callback)
{
  //var time = "2017-01-18T17:02:09.000+05:30"
  var date=new Date(datefrom);
 var day=date.getDate()+days;
  var stringDay=day<10?"0"+day:day;
  var month=date.getMonth()+1;
  var stringMonth=month<10?"0"+month:month;
  var hr = ("0" + date.getHours()).slice(-2);
  var min = ("0" + date.getMinutes()).slice(-2);
  var sec = ("0" + date.getSeconds()).slice(-2);
  var stringDate= date.getFullYear()+"-"+ stringMonth+"-"+ stringDay+"T"+hr+":"+min+":"+sec+"Z";
  console.log(stringDate);
  return callback(stringDate);

};

exports.helperFunctions = helperMethods;
