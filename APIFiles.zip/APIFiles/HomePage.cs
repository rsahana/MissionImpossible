﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dendrite.Framework;

namespace Nexxus.Metadata.MI.MI11._5.API
{
    class HomePage : MIMetadata
    {
        public HomePage() : base(
            regionCode: RegionCode.IN,
            teamCode: TeamCode.IN_MI,
            majorVersion: 11,
            softwareUpdate: 5,
            minSequence: 51600,
            maxSequence: 51699)
        {
            Language = "Mobile Intelligence";
            UserType = "Mobile Intelligence";
        }

        public override void ApplyMetadata()
        {
            CreatePropertyRole(roleName: "HAPI", roleDescription: "HomePage Message API", rootTable: "vt_homepage_message_api", parentRole: "ALL", useInTargeting: null, securityFunction: null);


            this.PropertyRole = "HAPI";
            AddEntity(entityName: "HomePage Message API", entityPropertyRole: "HAPI", parentEntity: "All Entities", permission: "R", apiFilter: null);
            AddEntityApi(entityName: "HomePage Message API", apiEntityName: "HomePage Message API", apiEnabled: 1, apiAccess: ApiAccess.All, createSecurityFunction: null, readSecurityFunction: null, updateSecurityFunction: null, deleteSecurityFunction: null);

            #region HomePage Message API

            AddEntityTable(entityName: "HomePage Message API", tableName: "vt_homepage_message_api", tableType: "OO", apiTableName: "HomePage_Message_API", apiEnabled: 1, apiAccess: ApiAccess.All);

            AddColumnToProperties(tableName: "vt_homepage_message_api", columnName: "HOMEPAGE_MESSAGE_ID", description: "HOMEPAGE MESSAGE ID API", controlType: ControlType.Integer, required: 0, minimum: 0, maximum: 9999999999999999);
            CreateInterfaceProperty(tableName: "vt_homepage_message_api", columnName: "HOMEPAGE_MESSAGE_ID", interfaceName: "HOMEPAGE MESSAGE ID API", fieldName: "HOMEPAGE_MESSAGE_IDENTIFIER", apiEnabled: 1, apiReadOnly: 0);

            AddColumnToProperties(tableName: "vt_homepage_message_api", columnName: "MESSAGE_TEXT", description: "MESSAGE TEXT API", controlType: ControlType.Text, required: 1, minimum: 0, maximum: 200);
            CreateInterfaceProperty(tableName: "vt_homepage_message_api", columnName: "MESSAGE_TEXT", interfaceName: "MESSAGE TEXT API", fieldName: "MESSAGE_TEXT", apiEnabled: 1, apiReadOnly: 0);

            AddColumnToProperties(tableName: "vt_homepage_message_api", columnName: "STATUS", description: "STATUS TEXT API", controlType: ControlType.Text, required: 1, minimum: 0, maximum: 4);
            CreateInterfaceProperty(tableName: "vt_homepage_message_api", columnName: "STATUS", interfaceName: "STATUS TEXT API", fieldName: "STATUS", apiEnabled: 1, apiReadOnly: 0);

            AddColumnToProperties(tableName: "vt_homepage_message_api", columnName: "CREATE_DATE", description: "CREATE DATE API", controlType: ControlType.Date, required: 1);
            CreateInterfaceProperty(tableName: "vt_homepage_message_api", columnName: "CREATE_DATE", interfaceName: "CREATE DATE API", fieldName: "CREATE_DATE", apiEnabled: 1, apiReadOnly: 0);

            AddColumnToProperties(tableName: "vt_homepage_message_api", columnName: "STATUS_CHANGE_DATE", description: "STATUS CHANGE DATE API", controlType: ControlType.Date, required: 1);
            CreateInterfaceProperty(tableName: "vt_homepage_message_api", columnName: "STATUS_CHANGE_DATE", interfaceName: "STATUS CHANGE DATE API", fieldName: "STATUS_CHANGE_DATE", apiEnabled: 1, apiReadOnly: 0);

            AddColumnToProperties(tableName: "vt_homepage_message_api", columnName: "MESSAGE_TYPE", description: "MESSAGE TYPE API", controlType: ControlType.Text, required: 1, minimum: 0, maximum: 4);
            CreateInterfaceProperty(tableName: "vt_homepage_message_api", columnName: "MESSAGE_TYPE", interfaceName: "MESSAGE TYPE API", fieldName: "MESSAGE_TYPE", apiEnabled: 1, apiReadOnly: 0);

            AddColumnToProperties(tableName: "vt_homepage_message_api", columnName: "USER_ACCOUNT_ID", description: "USER ACCOUNT ID API", controlType: ControlType.Integer, required: 0, minimum: 0, maximum: 9999999999999999);
            CreateInterfaceProperty(tableName: "vt_homepage_message_api", columnName: "USER_ACCOUNT_ID", interfaceName: "USER ACCOUNT ID API", fieldName: "USER_ACCOUNT_ID", apiEnabled: 1, apiReadOnly: 0);
            #endregion


        }
    }
}