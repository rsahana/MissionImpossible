﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dendrite.Framework;

namespace Nexxus.Metadata.MI.MI11._5.API
{
    class Appointment : MIMetadata
    {
        public Appointment() : base(
            regionCode: RegionCode.IN,
            teamCode: TeamCode.IN_MI,
            majorVersion: 11,
            softwareUpdate: 5,
            minSequence: 51500,
            maxSequence: 51599)
        {
            Language = "Mobile Intelligence";
            UserType = "Mobile Intelligence";
        }

        public override void ApplyMetadata()
        {
            CreatePropertyRole(roleName: "AAPI", roleDescription: "Appointment API", rootTable: "vt_appointment_api", parentRole: "ALL", filter: "vt_appointment_api.event_type='A'",
                                   useInTargeting: null, securityFunction: null);
            this.PropertyRole = "AAPI";

            AddEntity(entityName: "Appointment API", entityPropertyRole: "AAPI", parentEntity: "All Entities", permission: "R", apiFilter: null);
            AddEntityApi(entityName: "Appointment API", apiEntityName: "Appointment API", apiEnabled: 1, apiAccess: ApiAccess.All, createSecurityFunction: null, readSecurityFunction: null, updateSecurityFunction: null, deleteSecurityFunction: null);

            #region Appointment API

            AddEntityTable(entityName: "Appointment API", tableName: "vt_appointment_api", tableType: "OO", apiTableName: "Appointment_API", apiEnabled: 1, apiAccess: ApiAccess.All);

            AddColumnToProperties(tableName: "vt_appointment_api", columnName: "event_id", description: "APPOINTMENT API", controlType: ControlType.Integer, required: 0, minimum: 0, maximum: 9999999999999999);
            CreateInterfaceProperty(tableName: "vt_appointment_api", columnName: "event_id", interfaceName: "APPOINTMENT IDENTIFIER API", fieldName: "APPOINTMENT_IDENTIFIER", apiEnabled: 1, apiReadOnly: 0);

            AddColumnToProperties(tableName: "vt_appointment_api", columnName: "employee_id", description: "APPOINTMENT EMPLOYEE ID API", controlType: ControlType.Integer, required: 1, minimum: 0, maximum: 9999999999999999);
            CreateInterfaceProperty(tableName: "vt_appointment_api", columnName: "employee_id", interfaceName: "APPOINTMENT EMPLOYEE ID API", fieldName: "EMPLOYEE_ID", apiEnabled: 1, apiReadOnly: 0);

            AddColumnToProperties(tableName: "vt_appointment_api", columnName: "customer_id", description: "APPOINTMENT CUSTOMER ID API", controlType: ControlType.Integer, required: 0, minimum: 0, maximum: 9999999999999999);
            CreateInterfaceProperty(tableName: "vt_appointment_api", columnName: "customer_id", interfaceName: "APPOINTMENT CUSTOMER ID API", fieldName: "CUSTOMER_ID", apiEnabled: 1, apiReadOnly: 0);

            AddColumnToProperties(tableName: "vt_appointment_api", columnName: "event_sub_type", description: "APPOINTMENT EVENT SUB TYPE API", controlType: ControlType.Text, required: 1, minimum: 0, maximum: 4);
            CreateInterfaceProperty(tableName: "vt_appointment_api", columnName: "event_sub_type", interfaceName: "APPOINTMENT EVENT SUB TYPE API", fieldName: "EVENT_SUB_TYPE", apiEnabled: 1, apiReadOnly: 0);

            AddColumnToProperties(tableName: "vt_appointment_api", columnName: "event_type", description: "APPOINTMENT EVENT TYPE API", controlType: ControlType.Text, required: 1, minimum: 0, maximum: 4);
            CreateInterfaceProperty(tableName: "vt_appointment_api", columnName: "event_type", interfaceName: "APPOINTMENT EVENT TYPE API", fieldName: "EVENT_TYPE", apiEnabled: 1, apiReadOnly: 0);

            AddColumnToProperties(tableName: "vt_appointment_api", columnName: "status", description: "APPOINTMENT STATUS API", controlType: ControlType.Text, required: 1, minimum: 0, maximum: 4);
            CreateInterfaceProperty(tableName: "vt_appointment_api", columnName: "status", interfaceName: "APPOINTMENT STATUS API", fieldName: "STATUS", apiEnabled: 1, apiReadOnly: 0);

            AddColumnToProperties(tableName: "vt_appointment_api", columnName: "status_change_date", description: "APPOINTMENT STATUS CHANGE DATE API", controlType: ControlType.DateTime, required: 1);
            CreateInterfaceProperty(tableName: "vt_appointment_api", columnName: "status_change_date", interfaceName: "APPOINTMENT STATUS CHANGE DATE API", fieldName: "STATUS_CHANGE_DATE", apiEnabled: 1, apiReadOnly: 0);

            AddColumnToProperties(tableName: "vt_appointment_api", columnName: "START_DATE_TIME", description: "APPOINTMENT START DATE TIME API", controlType: ControlType.DateTime, required: 0, defaultData: null);
            CreateInterfaceProperty(tableName: "vt_appointment_api", columnName: "START_DATE_TIME", interfaceName: "APPOINTMENT START DATE TIME API", fieldName: "START_DATE_TIME", apiEnabled: 1, apiReadOnly: 0);

            AddColumnToProperties(tableName: "vt_appointment_api", columnName: "END_DATE_TIME", description: "APPOINTMENT END DATE TIME API", controlType: ControlType.DateTime, required: 0, defaultData: null);
            CreateInterfaceProperty(tableName: "vt_appointment_api", columnName: "END_DATE_TIME", interfaceName: "APPOINTMENT END DATE TIME API", fieldName: "END_DATE_TIME", apiEnabled: 1, apiReadOnly: 0);

            #endregion

            //AddColumnToProperties(tableName: "vt_calling_api", columnName: "customer_id", description: "CALLING CUSTOMER ID API", controlType: ControlType.Integer, required: 0, minimum: 0, maximum: 9999999999999999);
            //CreateInterfaceProperty(tableName: "vt_calling_api", columnName: "customer_id", interfaceName: "CALLING CUSTOMER ID API", fieldName: "CUSTOMER_ID", apiEnabled: 1, apiReadOnly: 0);

            //AddColumnToProperties(tableName: "vt_calling_api", columnName: "event_sub_type", description: "CALLING EVENT SUB TYPE API", controlType: ControlType.Text, required: 1, minimum: 0, maximum: 4);
            //CreateInterfaceProperty(tableName: "vt_calling_api", columnName: "event_sub_type", interfaceName: "CALLING EVENT SUB TYPE API", fieldName: "EVENT_SUB_TYPE", apiEnabled: 1, apiReadOnly: 0);

            //AddColumnToProperties(tableName: "vt_calling_api", columnName: "event_type", description: "CALLING EVENT TYPE API", controlType: ControlType.Text, required: 1, minimum: 0, maximum: 4);
            //CreateInterfaceProperty(tableName: "vt_calling_api", columnName: "event_type", interfaceName: "CALLING EVENT TYPE API", fieldName: "EVENT_TYPE", apiEnabled: 1, apiReadOnly: 0);

            //AddColumnToProperties(tableName: "vt_calling_api", columnName: "status", description: "CALLING STATUS API", controlType: ControlType.Text, required: 1, minimum: 0, maximum: 4);
            //CreateInterfaceProperty(tableName: "vt_calling_api", columnName: "status", interfaceName: "CALLING STATUS API", fieldName: "STATUS", apiEnabled: 1, apiReadOnly: 0);

            //AddColumnToProperties(tableName: "vt_calling_api", columnName: "status_change_date", description: "CALLING STATUS CHANGE DATE API", controlType: ControlType.DateTime, required: 1);
            //CreateInterfaceProperty(tableName: "vt_calling_api", columnName: "status_change_date", interfaceName: "CALLING STATUS CHANGE DATE API", fieldName: "STATUS_CHANGE_DATE", apiEnabled: 1, apiReadOnly: 0);

            //AddColumnToProperties(tableName: "vt_calling_api", columnName: "START_DATE_TIME", description: "CALLING START DATE TIME API", controlType: ControlType.DateTime, required: 0, defaultData: null);
            //CreateInterfaceProperty(tableName: "vt_calling_api", columnName: "START_DATE_TIME", interfaceName: "CALLING START DATE TIME API", fieldName: "START_DATE_TIME", apiEnabled: 1, apiReadOnly: 0);

           // #endregion
        }
    }
}
