﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dendrite.Framework;

namespace Nexxus.Metadata.MI.MI11._5.API
{
    class Call : MIMetadata
    {
        public Call():base(
            regionCode: RegionCode.APAC,
            teamCode: TeamCode.APAC_NZMI,
            majorVersion: 11,
            softwareUpdate: 5,
            minSequence:10000,
            maxSequence:19999)
        { }

        public override void ApplyMetadata()
        {
            CreatePropertyRole("CAPI", "Call API", "ALL", "vt_call_api", "vt_call_api.event_type='C'");
            base.PropertyRole = "CAPI";

            AddEntity("Call API", "CAPI", "All Entities", "R", "vt_call_api", "vt_call_api.event_type='C'");
            AddEntityApi(entityName: "Call API", apiEntityName: "Calls", apiEnabled: 1, apiAccess: ApiAccess.NoDelete, createSecurityFunction: null, readSecurityFunction: null, updateSecurityFunction: null, deleteSecurityFunction: null, forceSetExistingNonNullValuesToNull: true);

            #region Call API
            AddEntityTable(entityName:"Call API",tableName:"vt_call_api", tableType: "OO", apiTableName: "Call_API", apiEnabled: 1, apiAccess: ApiAccess.NoDelete, apiExternalIdentifier: "external_id_1");

            AddColumnToProperties("vt_call_api", "event_id", "Unique Identifier of Call (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_call_api", "event_id", "Unique Identifier of Call (API)", "CALL_IDENTIFIER", apiEnabled: 1, apiReadOnly: ApiReadOnly.Dynamic);

            AddColumnToProperties("vt_call_api", "customer_id", "Unique Entity Identifier of Customer (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_call_api", "customer_id", "Unique Entity Identifier of Customer (API)", "CUSTOMER_IDENTIFIER", apiEnabled: 1, apiReadOnly: ApiReadOnly.Dynamic);

            AddColumnToProperties("vt_call_api", "vc_entity_type", "Entity Type of Customer (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 0,requestType: ComboRequestType.Role, request: "call.entity_type");
            CreateInterfaceProperty("vt_call_api", "vc_entity_type", "Entity Type of Customer (API)", "ENTITY_TYPE", apiEnabled: 1);
            AddCodeRole("call.entity_type", "I", "Individual");
            AddCodeRole("call.entity_type", "O", "Organization");

            AddColumnToProperties("vt_call_api", "employee_id", "Unique Identifier of Employee (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 1);
            CreateInterfaceProperty("vt_call_api", "employee_id", "Unique Identifier of Employee (API)", "EMPLOYEE_IDENTIFIER", apiEnabled: 1, apiReadOnly: ApiReadOnly.Dynamic);
            //mapping alignment id
            AddColumnToProperties("vt_call_api", "alignment_id", "Value of Sales Area (API)", controlType: ControlType.Integer, minimum: 0, maximum: 999999999999999, required: 1, scale: 2);
            CreateInterfaceProperty("vt_call_api", "alignment_id", "Value of Sales Area (API)", "SALES_AREA_IDENTIFIER", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "vc_sales_force_name", "Value of the Sales Force (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 1);
            CreateInterfaceProperty("vt_call_api", "vc_sales_force_name", "Value of the Sales Force (API)", "SALES_FORCE_IDENTIFIER", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "event_type", "Type of the Call (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 1,requestType: ComboRequestType.Role,request: "event/event_type", defaultData: "C");
            CreateInterfaceProperty("vt_call_api", "event_type", "Type of the Call (API)", "CALL_TYPE_CODE", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "event_sub_type", "Subtype of the Call (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 1,request: "event/event_sub_type/call",requestType: ComboRequestType.Role);
            CreateInterfaceProperty("vt_call_api", "event_sub_type", "Subtype of the Call (API)", "CALL_SUBTYPE_CODE", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "start_date_time", "Date of the Call (API)", controlType: ControlType.DateTime, defaultData:"@LOCAL_NOW", required: 1);
            CreateInterfaceProperty("vt_call_api", "start_date_time", "Date of the Call (API)", "CALL_DATE", apiEnabled: 1);

            AddColumnToProperties("vt_call_api",  "status", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 1, requestType: ComboRequestType.Role, request: "call.status", defaultData: "OPEN", description: "Status of the Call (API)");
            CreateInterfaceProperty("vt_call_api", "status", "Status of the Call (API)", "CALL_STATUS_CODE", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "samples_document_id", "Unique Control ID of Sample Form (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 0);
            CreateInterfaceProperty("vt_call_api", "samples_document_id", "Unique Control ID of Sample Form (API)", "SAMPLE_DOCUMENT_IDENTIFIER", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "state_license_number", "State License Number of Customer (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 0);
            CreateInterfaceProperty("vt_call_api", "state_license_number", "State License Number of Customer (API)", "STATE_LICENCE_IDENTIFIER", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "vc_state_license_state_name", "State of State Licence (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 0);
            CreateInterfaceProperty("vt_call_api", "vc_state_license_state_name", "State of State Licence (API)", "STATE_LICENCE_STATE_NAME", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "vc_state_license_expiration_date", "Expiration Date of State Licence (API)", controlType: ControlType.Date, required: 0);
            CreateInterfaceProperty("vt_call_api", "vc_state_license_expiration_date", "Expiration Date of State Licence (API)", "STATE_LICENCE_EXPIRATION_DATE", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "vc_dea_number_identifier", "DEA Number of Customer (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 0);
            CreateInterfaceProperty("vt_call_api", "vc_dea_number_identifier", "DEA Number of Customer (API)", "DEA_NUMBER_IDENTIFIER", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "vc_dea_expiration_date", "Expiration Date of DEA Number (API)", controlType: ControlType.Date, required: 0);
            CreateInterfaceProperty("vt_call_api", "vc_dea_expiration_date", "Expiration Date of DEA Number (API)", "DEA_EXPIRATION_DATE", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "vc_sampling_status_code", "Sampling Status of Customer (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 0, requestType: ComboRequestType.Role, request: "sampling_status", defaultData: "PEND");
            CreateInterfaceProperty("vt_call_api", "vc_sampling_status_code", "Sampling Status of Customer (API)", "SAMPLING_STATUS_CODE", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "vc_professional_suffix_code", "Professional Suffix of Customer (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 0, requestType: ComboRequestType.Role, request: "prof_suffix");
            CreateInterfaceProperty("vt_call_api", "vc_professional_suffix_code", "Professional Suffix of Customer (API)", "PROFESSIONAL_SUFFIX_CODE", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "vc_address_identifier", "Address Identifier of Call (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_call_api", "vc_address_identifier", "Address Identifier of Call (API)", "ADDRESS_IDENTIFIER", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "vc_address_line1", "Line 1 of Address (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 0);
            CreateInterfaceProperty("vt_call_api", "vc_address_line1", "Line 1 of Address (API)", "ADDRESS_LINE1", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "vc_address_line2", "Line 2 of Address (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 0);
            CreateInterfaceProperty("vt_call_api", "vc_address_line2", "Line 2 of Address (API)", "ADDRESS_LINE2", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "vc_address_line3", "Line 3 of Address (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 0);
            CreateInterfaceProperty("vt_call_api", "vc_address_line3", "Line 3 of Address (API)", "ADDRESS_LINE3", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "vc_city_name", "City of Address (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 0);
            CreateInterfaceProperty("vt_call_api", "vc_city_name", "City of Address (API)", "CITY_NAME", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "vc_region_name", "Region of Address (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 0);
            CreateInterfaceProperty("vt_call_api", "vc_region_name", "Region of Address (API)", "REGION_NAME", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "vc_postal_area", "Postal Area of Address (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 0);
            CreateInterfaceProperty("vt_call_api", "vc_postal_area", "Postal Area of Address (API)", "POSTAL_AREA", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "vc_postal_area_extension", "Postal Area Extension of Address (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 0);
            CreateInterfaceProperty("vt_call_api", "vc_postal_area_extension", "Postal Area Extension of Address (API)", "POSTAL_AREA_EXTENSION", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "vc_organization_name", "Organization Name of Call (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 0);
            CreateInterfaceProperty("vt_call_api", "vc_organization_name", "Organization Name of Call (API)", "ORGANIZATION_NAME", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "vc_org_address_line1", "Line 1 of Organization Address (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 0);
            CreateInterfaceProperty("vt_call_api", "vc_org_address_line1", "Line 1 of Organization Address (API)", "ORG_ADDRESS_LINE1", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "vc_org_address_line2", "Line 2 of Organization Address (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 0);
            CreateInterfaceProperty("vt_call_api", "vc_org_address_line2", "Line 2 of Organization Address (API)", "ORG_ADDRESS_LINE2", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "vc_org_address_line3", "Line 3 of Organization Address (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 0);
            CreateInterfaceProperty("vt_call_api", "vc_org_address_line3", "Line 3 of Organization Address (API)", "ORG_ADDRESS_LINE3", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "vc_org_city_name", "City of Organization Address (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 0);
            CreateInterfaceProperty("vt_call_api", "vc_org_city_name", "City of Organization Address (API)", "ORG_CITY_NAME", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "vc_org_region_name", "Region of Organization Address (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 0);
            CreateInterfaceProperty("vt_call_api", "vc_org_region_name", "Region of Organization Address (API)", "ORG_REGION_NAME", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "vc_org_postal_area", "Postal Area of Oragnization Address (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 0);
            CreateInterfaceProperty("vt_call_api", "vc_org_postal_area", "Postal Area of Oragnization Address (API)", "ORG_POSTAL_AREA", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "vc_org_postal_area_extension", "Postal Area Extension of Oragnization Address (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 0);
            CreateInterfaceProperty("vt_call_api", "vc_org_postal_area_extension", "Postal Area Extension of Oragnization Address (API)", "ORG_POSTAL_AREA_EXTENSION", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "vc_org_country_code", "Country of Organization Address (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 0, request: "country",requestType: ComboRequestType.Role);
            CreateInterfaceProperty("vt_call_api", "vc_org_country_code", "Country of Organization Address (API)", "ORG_COUNTRY_CODE", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "prescribers_seen", "Number of Prescriber of Call (API)", controlType: ControlType.Integer, minimum: 0, maximum: 999999999, required: 0);
            CreateInterfaceProperty("vt_call_api", "prescribers_seen", "Number of Prescriber of Call (API)", "PRESCRIBER_SEEN_COUNT", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "call_value", "Call Value Based on Customer and Contact (API)", controlType: ControlType.Float, minimum: 0, maximum: 1000, required: 0, scale: 2);
            CreateInterfaceProperty("vt_call_api", "call_value", "Call Value Based on Customer and Contact (API)", "CALL_AMOUNT", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "contact_type", "Type of Contact (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 0,requestType: ComboRequestType.Role,request: "contact_type");
            CreateInterfaceProperty("vt_call_api", "contact_type", "Type of Contact (API)", "CONTACT_TYPE_CODE", apiEnabled: 1);
            // no code role matching
            AddColumnToProperties("vt_call_api", "audience", "Audience of Customer (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 0,requestType: ComboRequestType.Role, request: "event/audience");
            CreateInterfaceProperty("vt_call_api", "audience", "Audience of Customer (API)", "AUDIENCE_CODE", apiEnabled: 1);
            // no code role matching
            AddColumnToProperties("vt_call_api", "not_visited_reason", "Reason Call is Not Recorded (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 0,requestType: ComboRequestType.Role, request: "event/not_visited_reason");
            CreateInterfaceProperty("vt_call_api", "not_visited_reason", "Reason Call is Not Recorded (API)", "NOT_VISITED_REASON_CODE", apiEnabled: 1);
            // no code role matching
            AddColumnToProperties("vt_call_api", "business_issue", "Specific Business Issue (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 0, requestType: ComboRequestType.Role, request: "event/business_issue");
            CreateInterfaceProperty("vt_call_api", "business_issue", "Specific Business Issue (API)", "BUSINESS_ISSUE_CODE", apiEnabled: 1);
            // no code role matching
            AddColumnToProperties("vt_call_api", "category", "Category of Call (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 0,requestType: ComboRequestType.Role, request: "event/category");
            CreateInterfaceProperty("vt_call_api", "category", "Category of Call (API)", "BUYING_CYCLE_CODE", apiEnabled: 1);       

            AddColumnToProperties("vt_call_api", "accompanied_by", "Person who Accompanies Rep (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 0,request: "accompanied_by", requestType: ComboRequestType.Role);
            CreateInterfaceProperty("vt_call_api", "accompanied_by", "Person who Accompanies Rep (API)", "ACCOMPANIED_BY_CODE", apiEnabled: 1);
            // no code role matching
            AddColumnToProperties("vt_call_api", "vc_disbursement_type_code", "Disbursement Type of Call (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 1, requestType: ComboRequestType.Role, request: "call.disbursement_type", defaultData: "LE");
            CreateInterfaceProperty("vt_call_api", "vc_disbursement_type_code", "Disbursement Type of Call (API)", "DISBURSEMENT_TYPE_CODE", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "receipt_requested", "Indicate if Receipt of Sample Requested (API)", controlType: ControlType.CheckBox, minimum: 0, maximum: 1, required: 0);
            CreateInterfaceProperty("vt_call_api", "receipt_requested", "Indicate if Receipt of Sample Requested (API)", "RECEIPT_RECORD_FLAG", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "rep_state_license_number", "State Licence Number Entered By Rep (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 0);
            CreateInterfaceProperty("vt_call_api", "rep_state_license_number", "State Licence Number Entered By Rep (API)", "REP_STATE_LICENCE_IDENTIFIER", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "creator_employee_id", "Creator Employee Identifier (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_call_api", "creator_employee_id", "Creator Employee Identifier (API)", "EMPLOYEE_NAME", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "rep_entered_dea_number", "DEA Number Entered By Rep (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 0);
            CreateInterfaceProperty("vt_call_api", "rep_entered_dea_number", "DEA Number Entered By Rep (API)", "REP_ENTERED_DEA_IDENTIFIER", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "rep_entered_dea_expiration", "DEA Number Expiration Date Entered By Rep (API)", controlType: ControlType.Date, required: 0);
            CreateInterfaceProperty("vt_call_api", "rep_entered_dea_expiration", "DEA Number Expiration Date Entered By Rep (API)", "REP_ENTERED_DEA_EXPIRATION_DATE", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "rep_entered_dea_schedule", "The DEA schedule entered by the rep (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 0);
            CreateInterfaceProperty("vt_call_api", "rep_entered_dea_schedule", "The DEA schedule entered by the rep (API)", "REP_ENTERED_DEA_SCHEDULE", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "entry_date", "Date Call Entered into System (API)", controlType: ControlType.Date, required: 0, readOnly: ReadOnlyType.Always, defaultData: "@NOW");
            CreateInterfaceProperty("vt_call_api", "entry_date", "Date Call Entered into System (API)", "ENTRY_DATE", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "vc_region_identifier", "Unique global identifier for Region (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_call_api", "vc_region_identifier", "Unique global identifier for Region (API)", "REGION_IDENTIFIER", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "vc_business_unit_identifier", "Unique global identifier for Business_Unit (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_call_api", "vc_business_unit_identifier", "Unique global identifier for Business_Unit (API)", "BUSINESS_UNIT_IDENTIFIER", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "host_process_date", "Host Process Date of Call (API)", controlType: ControlType.Date, minimum: 0, maximum: 200, required: 0, readOnly: ReadOnlyType.Always, defaultData: "@NOW");
            CreateInterfaceProperty("vt_call_api", "host_process_date", "Host Process Date of Call (API)", "HOST_ENTRY_DATE", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "group_call_id", "Unique identifer of Group Call (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_call_api", "group_call_id", "Unique identifer of Group Call (API)", "GROUP_CALL_IDENTIFIER", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "time_of_call", "Duration of call in minutes (API)", controlType: ControlType.Integer, minimum: 0, maximum: 9999, required: 0, defaultData: "10");
            CreateInterfaceProperty("vt_call_api", "time_of_call", "Duration of call in minutes (API)", "TIME_OF_CALL_COUNT", apiEnabled: 1);
            // no exact matching found
            AddColumnToProperties("vt_call_api", "appointment_type", "Call Appointment Type (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 0, requestType: ComboRequestType.Role, request: "event/appointment_type");
            CreateInterfaceProperty("vt_call_api", "appointment_type", "Call Appointment Type (API)", "APPOINTMENT_TYPE_CODE", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "reminder_date_time", "Call Reminder Date Time (API)", controlType: ControlType.Date, required: 0);
            CreateInterfaceProperty("vt_call_api", "reminder_date_time", "Call Reminder Date Time (API)", "REMINDER_DATE_TIME", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "meeting_id", "Unique global identifier of the Meeting (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_call_api", "meeting_id", "Unique global identifier of the Meeting (API)", "MEETING_IDENTIFIER", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "project_id", "Client Project of Call (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_call_api", "project_id", "Client Project of Call (API)", "PROJECT_IDENTIFIER", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "poa_event_id", "Unique global identifier of POA_Call (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_call_api", "poa_event_id", "Unique global identifier of POA_Call (API)", "POA_CALL_IDENTIFIER", apiEnabled: 1, apiReadOnly: ApiReadOnly.Dynamic);

            AddColumnToProperties("vt_call_api", "purpose", "Indicates the purpose of the call (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 0, request: "call purpose", requestType: ComboRequestType.Role);
            CreateInterfaceProperty("vt_call_api", "purpose", "Indicates the purpose of the call (API)", "PURPOSE_CODE", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "interaction_channel", "Channel for interaction (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 1, request: "interaction_channel", requestType: ComboRequestType.Role);
            CreateInterfaceProperty("vt_call_api", "interaction_channel", "Channel for interaction (API)", "INTERACTION_CHANNEL_CODE", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "total_attendee_count", "Total Number of Attendees in Call (API)", controlType: ControlType.Integer, minimum: 0, maximum: 999999999, required: 0);
            CreateInterfaceProperty("vt_call_api", "total_attendee_count", "Total Number of Attendees in Call (API)", "TOTAL_ATTENDEES_COUNT", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "total_employee_count", "Total Number of Employees of Call", controlType: ControlType.Integer, minimum: 0, maximum: 999999999, required: 0);
            CreateInterfaceProperty("vt_call_api", "total_employee_count", "Total Number of Employees of Call", "TOTAL_EMPLOYEES_COUNT", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "vc_customer_sales_area_cycle_code", "Cycle of Customer Sales Area (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 0,requestType: ComboRequestType.TableColumn);
            CreateInterfaceProperty("vt_call_api", "vc_customer_sales_area_cycle_code", "Cycle of Customer Sales Area (API)", "CUSTOMER_SALES_AREA_CYCLE_CODE", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "call_plan_template_id", "Unique identifier of Call_Plan_Template (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_call_api", "call_plan_template_id", "Unique identifier of Call_Plan_Template (API)", "CALL_PLAN_TEMPLATE_NAME", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "owner_confirm_status", "Confirmation Status by Owner of Call (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 0, requestType: ComboRequestType.Role, request: "comment_confirmation_status");
            CreateInterfaceProperty("vt_call_api", "owner_confirm_status", "Confirmation Status by Owner of Call (API)", "OWNER_CONFIRM_STATUS_CODE", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "manager_confirm_status", "Confirmation Status by Manager of Owner of Call (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 0, requestType: ComboRequestType.Role, request: "comment_confirmation_status");
            CreateInterfaceProperty("vt_call_api", "manager_confirm_status", "Confirmation Status by Manager of Owner of Call (API)", "MANAGER_CONFIRM_STATUS_CODE", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "source", "Source of Call (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 0, requestType: ComboRequestType.Role, request: "event_source", defaultData: "CDMI");
            CreateInterfaceProperty("vt_call_api", "source", "Source of Call (API)", "SOURCE_CODE", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "period_id", "Period of Call (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_call_api", "period_id", "Period of Call (API)", "PERIOD_IDENTIFIER", apiEnabled: 1);

            AddColumnToProperties("vt_call_api", "external_id_1", "Client Call Identifier (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 1);
            CreateInterfaceProperty("vt_call_api", "external_id_1", "Client Call Identifier (API)", "CLIENT_CALL_IDENTIFIER", apiEnabled: 1,apiReadOnly: ApiReadOnly.Immutable);

            AddColumnToProperties("vt_call_api", "LAST_HOST_UPDATE_DATE", "Last Host Update Date (API)", controlType: ControlType.Date, minimum: null, maximum: null, required: 0);
            CreateInterfaceProperty("vt_call_api", "LAST_HOST_UPDATE_DATE", "Last Host Update Date (API)", "LAST_UPDATE_DATE", apiEnabled: 1, apiReadOnly: ApiReadOnly.Always);

            AddColumnToProperties("vt_call_api", "last_entity_update_date", "Last Entity Update Date (API)", controlType: ControlType.Date, minimum: null, maximum: null, required: 0);
            CreateInterfaceProperty("vt_call_api", "last_entity_update_date", "Last Entity Update Date (API)", "LAST_ENTITY_UPDATE_DATE", apiEnabled: 1,apiReadOnly: ApiReadOnly.Always);
            #endregion
            #region Call API NOT MAPPED
            //AddColumnToProperties("vt_call_api", "cost", "", controlType: ControlType.Integer, minimum: 0, maximum: 9999, required: 0);
            //CreateInterfaceProperty("vt_call_api", "cost", "", "COST", apiEnabled: 0);

            //AddColumnToProperties("vt_call_api", "preparation_duration", "", controlType: ControlType.Integer, minimum: 0, maximum: 9999, required: 0);
            //CreateInterfaceProperty("vt_call_api", "preparation_duration", "", "PREP_DURATION", apiEnabled: 0);

            //AddColumnToProperties("vt_call_api", "account_call", "", controlType: ControlType.CheckBox, minimum: 0, maximum: 200, required: 0);
            //CreateInterfaceProperty("vt_call_api", "account_call", "", "ACCOUNT_CALL", apiEnabled: 0);

            AddColumnToProperties(tableName: "vt_call_api", columnName: "affiliation_id", controlType: ControlType.Integer, minimum: long.MinValue,maximum: long.MaxValue,required: 0,description: "Location");
            CreateInterfaceProperty("vt_call_api", "affiliation_id", "", "", 0,apiReadOnly: ApiReadOnly.Always);

            //AddColumnToProperties(tableName: "vt_call_api", columnName: "alignment_id", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0, description: "Sales Force");
            //CreateInterfaceProperty("vt_call_api", "alignment_id", "", "", 0,apiReadOnly: ApiReadOnly.Always);

            //AddColumnToProperties(tableName: "vt_call_api",columnName: "clm_group_call_id", controlType: ControlType.Text,  minimum: 0,maximum: 200,required: 0,description: "");
            //CreateInterfaceProperty("vt_call_api", "clm_group_call_id", "", "", 0);

            //AddColumnToProperties(tableName: "vt_call_api",columnName: "clm_id",controlType: ControlType.Text, minimum: 0, maximum: 200, required: 0, description: "");
            //CreateInterfaceProperty("vt_call_api", "clm_id", "", "", 0);

            //AddColumnToProperties(tableName: "vt_call_api",columnName: "clm_status", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 0,request: "status", requestType: ComboRequestType.Role,description: "");
            //CreateInterfaceProperty("vt_call_api", "clm_status", "", "", 0);

            //AddColumnToProperties(tableName: "vt_call_api",columnName: "end_date_time",controlType: ControlType.Date, minimum: 0,maximum: 200,required: 0,description: "");
            //CreateInterfaceProperty("vt_call_api", "end_date_time", "", "", 0);

            //AddColumnToProperties(tableName: "vt_call_api",columnName: "event_significance",controlType: ControlType.CheckBox,minimum: 0,maximum: 200,required: 0,description: "");
            //CreateInterfaceProperty("vt_call_api", "event_significance", "", "", 0);

            //AddColumnToProperties(tableName: "vt_call_api",columnName: "event_user_type",controlType: ControlType.DropDown, minimum: 0, maximum: 200,  required: 0,  requestType: ComboRequestType.Role, request: "event_user_type", defaultData: "DO", description: "");
            //CreateInterfaceProperty("vt_call_api", "event_user_type", "", "", 0);


            //AddColumnToProperties(tableName: "vt_call_api",columnName: "is_future_call", controlType: ControlType.CheckBox, minimum: 0,maximum: 200,required: 0, description: "");
            //CreateInterfaceProperty("vt_call_api", "is_future_call", "", "", 0);

            //AddColumnToProperties(tableName: "vt_call_api",columnName: "refused_to_sign", controlType: ControlType.CheckBox, minimum: 0,maximum: 200,required: 0,description: "");
            //CreateInterfaceProperty("vt_call_api", "refused_to_sign", "", "", 0);

            //AddColumnToProperties(tableName: "vt_call_api",columnName: "signed_for_details",controlType: ControlType.CheckBox,minimum: 0,maximum: 200,required: 0,description: "");
            //CreateInterfaceProperty("vt_call_api", "signed_for_details", "", "", 0);

            //DONE: new dropdonw
            

            AddColumnToProperties(tableName: "vt_call_api", columnName: "status_change_date", controlType: ControlType.Date, minimum: 0, maximum: 200, required: 0, defaultData: "@NOW", description: "Status Change Date (API)");
            CreateInterfaceProperty("vt_call_api", "status_change_date", "", "", 0,apiReadOnly:ApiReadOnly.Always);
            #endregion
            #region Call Detail API

            AddEntityTable(entityName: "Call API", tableName: "vt_call_detail_api", tableType: "OM", apiTableName: "Call_Detail_API", apiEnabled: 1, apiAccess: ApiAccess.NoDelete, apiExternalIdentifier: "external_id_1");

            AddColumnToProperties("vt_call_detail_api", "event_detail_id", "Unique Identifier Call Detail (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_call_detail_api", "event_detail_id", "Unique Identifier Call Detail (API)", "CALL_DETAIL_IDENTIFIER", apiEnabled: 1,apiReadOnly: ApiReadOnly.Dynamic);

            AddColumnToProperties("vt_call_detail_api", "product_id", "Unique Call Detail Product Identifier (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 1);
            CreateInterfaceProperty("vt_call_detail_api", "product_id", "Unique Call Detail Product Identifier (API)", "PRODUCT_IDENTIFIER", apiEnabled: 1,apiReadOnly: ApiReadOnly.Dynamic);

            AddColumnToProperties("vt_call_detail_api", "sequence", "Call Detail Presentation Sequence (API)", controlType: ControlType.Integer, minimum: 0, maximum: 999999999, required: 0);
            CreateInterfaceProperty("vt_call_detail_api", "sequence", "Call Detail Presentation Sequence (API)", "SEQUENCE_NUMBER", apiEnabled: 1);

            AddColumnToProperties("vt_call_detail_api", "reaction_type", "Physician Reaction Code (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 0, requestType: ComboRequestType.Role, request: "event_detail/reaction_type");
            CreateInterfaceProperty("vt_call_detail_api", "reaction_type", "Physician Reaction Code (API)", "INDICATION_CODE", apiEnabled: 1);

            AddColumnToProperties("vt_call_detail_api", "detail_comment_code", "Comments During the Call (API)", controlType: ControlType.Text, minimum: 0, maximum: 4, required: 0, requestType: ComboRequestType.TableColumn);
            CreateInterfaceProperty("vt_call_detail_api", "detail_comment_code", "Comments During the Call (API)", "DETAIL_COMMENT_TEXT", apiEnabled: 1);

            AddColumnToProperties("vt_call_detail_api", "time_spent", "Time Spent on Product (API)", controlType: ControlType.Integer, minimum: 0, maximum: 999999999, required: 1);
            CreateInterfaceProperty("vt_call_detail_api", "time_spent", "Time Spent on Product (API)", "TIME_SPENT_COUNT", apiEnabled: 1);

            AddColumnToProperties("vt_call_detail_api", "poa_segment_detail_id", "Unique Identifier of POA Segment of Type CAMP (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_call_detail_api", "poa_segment_detail_id", "Unique Identifier of POA Segment of Type CAMP (API)", "POA_SEGMENT_DETAIL_IDENTIFIER", apiEnabled: 1, apiReadOnly: ApiReadOnly.Dynamic);

            AddColumnToProperties("vt_call_detail_api", "call_plan_template_id", "Unique Identifier of Call Plan Template (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_call_detail_api", "call_plan_template_id", "Unique Identifier of Call Plan Template (API)", "CALL_PLAN_TEMPLATE_NAME", apiEnabled: 1);

            AddColumnToProperties("vt_call_detail_api", "dn_rating_attribute_id", "Unique Identifier of Rating Attribute (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_call_detail_api", "dn_rating_attribute_id", "Unique Identifier of Rating Attribute (API)", "RATING_ATTRIBUTE_IDENTIFIER", apiEnabled: 1);

            AddColumnToProperties("vt_call_detail_api", "external_id_1", "Client Call Detail Identifier (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 1);
            CreateInterfaceProperty("vt_call_detail_api", "external_id_1", "Client Call Detail Identifier (API)", "CLIENT_CALL_DETAIL_IDENTIFIER", apiEnabled: 1, apiReadOnly: ApiReadOnly.Immutable);

            AddColumnToProperties("vt_call_detail_api", "event_id", "Unique Identifier For Call (API)", controlType: ControlType.Integer, minimum: null, maximum: null, required: 0);
            CreateInterfaceProperty("vt_call_detail_api", "event_id", "Unique Identifier For Call (API)", "CALL_IDENTIFIER", apiEnabled: 0);

            AddColumnToProperties("vt_call_detail_api", "LAST_HOST_UPDATE_DATE", "Last Host Update Date (API)", controlType: ControlType.Date, minimum: null, maximum: null, required: 0);
            CreateInterfaceProperty("vt_call_detail_api", "LAST_HOST_UPDATE_DATE", "Last Host Update Date (API)", "LAST_UPDATE_DATE", apiEnabled: 1, apiReadOnly: ApiReadOnly.Always);
            #endregion
            #region Call Address API
            //AddEntityTable(entityName: "Call API", tableName: "vt_call_address_api", tableType: "OO", apiTableName: "Call_Address_API", apiEnabled: 1, apiAccess: ApiAccess.NoDelete, apiExternalIdentifier: "external_id_1");

            //AddColumnToProperties("vt_call_address_api", "event_id", "Unique Identifier of Call Address (API)", controlType: ControlType.Integer, minimum: null, maximum: null, required: 0);
            //CreateInterfaceProperty("vt_call_address_api", "event_id", "Unique Identifier of Call Address (API)", "CALL_ADDRESS_IDENTIFIER", apiEnabled: 1, apiReadOnly: ApiReadOnly.Dynamic);

            //AddColumnToProperties("vt_call_address_api", "address_id", "Unique Identifier of Address (API)", controlType: ControlType.Integer, minimum: null, maximum: null, required: 0);
            //CreateInterfaceProperty("vt_call_address_api", "address_id", "Unique Identifier of Address (API)", "ADDRESS_IDENTIFIER", apiEnabled: 1, apiReadOnly: ApiReadOnly.Dynamic);

            //AddColumnToProperties("vt_call_address_api", "to_name", "Affiliation of Address (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 0);
            //CreateInterfaceProperty("vt_call_address_api", "to_name", "Affiliation of Address (API)", "TO_NAME", apiEnabled: 1);

            //AddColumnToProperties("vt_call_address_api", "line_1_address", "Line 1 of Address (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 0);
            //CreateInterfaceProperty("vt_call_address_api", "line_1_address", "Line 1 of Address (API)", "LINE_1_ADDRESS", apiEnabled: 1);

            //AddColumnToProperties("vt_call_address_api", "line_2_address", "Line 2 of Address (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 0);
            //CreateInterfaceProperty("vt_call_address_api", "line_2_address", "Line 2 of Address (API)", "LINE_2_ADDRESS", apiEnabled: 1);

            //AddColumnToProperties("vt_call_address_api", "line_3_address", "Line 3 of Address (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 0);
            //CreateInterfaceProperty("vt_call_address_api", "line_3_address", "Line 3 of Address (API)", "LINE_3_ADDRESS", apiEnabled: 1);

            //AddColumnToProperties("vt_call_address_api", "city", "City Name of Address (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 0);
            //CreateInterfaceProperty("vt_call_address_api", "city", "City Name of Address (API)", "CITY_NAME", apiEnabled: 1);

            //AddColumnToProperties("vt_call_address_api", "state", "State Name of Address (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 0);
            //CreateInterfaceProperty("vt_call_address_api", "state", "State Name of Address (API)", "STATE_NAME", apiEnabled: 1);

            //AddColumnToProperties("vt_call_address_api", "postal_area", "Zip Code of Address (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 0);
            //CreateInterfaceProperty("vt_call_address_api", "postal_area", "Zip Code of Address (API)", "POSTAL_AREA", apiEnabled: 1);

            //AddColumnToProperties("vt_call_address_api", "external_id_1", "Client Call Address Identifier (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 1);
            //CreateInterfaceProperty("vt_call_address_api", "external_id_1", "Client Call Address Identifier (API)", "CLIENT_CALL_ADDRESS_INDENTIFIER", apiEnabled: 1, apiReadOnly: ApiReadOnly.Immutable);
            #endregion
            #region Call Promotion API
            AddEntityTable(entityName: "Call API", tableName: "vt_call_promotion_api", tableType: "OM", apiTableName: "Call_Promotion_API", apiEnabled: 1, apiAccess: ApiAccess.NoDelete, apiExternalIdentifier: "external_id");

            AddColumnToProperties("vt_call_promotion_api", "event_item_id", "Unique Identifier of Call Promotion (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_call_promotion_api", "event_item_id", "Unique Identifier of Call Promotion (API)", "CALL_ITEM_IDENTIFIER", apiEnabled: 1,apiReadOnly: ApiReadOnly.Dynamic);

            AddColumnToProperties("vt_call_promotion_api", "product_id", "Unique Product Identifier (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 1);
            CreateInterfaceProperty("vt_call_promotion_api", "product_id", "Unique Product Identifier (API)", "PRODUCT_IDENTIFIER", apiEnabled: 1,apiReadOnly: ApiReadOnly.Dynamic);

            AddColumnToProperties("vt_call_promotion_api", "quantity", "Total Number of Items (API)", controlType: ControlType.Integer, minimum: 0, maximum: 999999999, required: 1);
            CreateInterfaceProperty("vt_call_promotion_api", "quantity", "Total Number of Items (API)", "QUANTITY", apiEnabled: 1);

            AddColumnToProperties("vt_call_promotion_api", "note", "Promotional Item Notes (API)", controlType: ControlType.Text, minimum: 0, maximum: 2000, required: 0);
            CreateInterfaceProperty("vt_call_promotion_api", "note", "Promotional Item Notes (API)", "NOTE_TEXT", apiEnabled: 1);

            AddColumnToProperties("vt_call_promotion_api", "external_id", "Client Call Promotion Identifier (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 1);
            CreateInterfaceProperty("vt_call_promotion_api", "external_id", "Client Call Promotion Identifier (API)", "CLIENT_CALL_ITEM_IDENTIFIER", apiEnabled: 1, apiReadOnly: ApiReadOnly.Immutable);

            AddColumnToProperties("vt_call_promotion_api", "event_id", "Unique Identifier for Call (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_call_promotion_api", "event_id", "Unique Identifier for Call (API)", "CALL_IDENTIFIER", apiEnabled: 0);

            AddColumnToProperties("vt_call_promotion_api", "LAST_HOST_UPDATE_DATE", "Last Host Update Date (API)", controlType: ControlType.Date, minimum: null, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_call_promotion_api", "LAST_HOST_UPDATE_DATE", "Last Host Update Date (API)", "LAST_UPDATE_DATE", apiEnabled: 1, apiReadOnly: ApiReadOnly.Always);
            //add external_id_1
            #endregion
            #region Call Message API
            AddEntityTable(entityName: "Call API", tableName: "vt_call_message_api", tableType: "OM", apiTableName: "Call_Message_API", apiEnabled: 1, apiAccess: ApiAccess.NoDelete, apiExternalIdentifier: "external_id_1");

            AddColumnToProperties("vt_call_message_api", "event_message_id", "Unique Identifier of Call Message (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_call_message_api", "event_message_id", "Unique Identifier of Call Message (API)", "CALL_MESSAGE_IDENTIFIER", apiEnabled: 1, apiReadOnly: ApiReadOnly.Dynamic);

            AddColumnToProperties("vt_call_message_api", "external_id_1", "Client Call Message Identifier (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 1);
            CreateInterfaceProperty("vt_call_message_api", "external_id_1", "Client Call Message Identifier (API)", "CLIENT_CALL_MESSAGE_IDENTIFIER", apiEnabled: 1, apiReadOnly: ApiReadOnly.Immutable);

            AddColumnToProperties("vt_call_message_api", "product_id", "Unique Product Identifier (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 1);
            CreateInterfaceProperty("vt_call_message_api", "product_id", "Unique Product Identifier (API)", "PRODUCT_IDENTIFIER", apiEnabled: 1, apiReadOnly: ApiReadOnly.Dynamic);

            AddColumnToProperties("vt_call_message_api", "product_message_id", "Unique Identifier for Product Message (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 1);
            CreateInterfaceProperty("vt_call_message_api", "product_message_id", "Unique Identifier for Product Message (API)", "PRODUCT_MESSAGE_IDENTIFIER", apiEnabled: 1, apiReadOnly: ApiReadOnly.Dynamic);

            AddColumnToProperties("vt_call_message_api", "due_date", "Follow Up Date (API)", controlType: ControlType.Date, required: 0);
            CreateInterfaceProperty("vt_call_message_api", "due_date", "Follow Up Date (API)", "DUE_DATE", apiEnabled: 1);

            AddColumnToProperties("vt_call_message_api", "reaction_type", "Role of Attendee When Invited (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 0, requestType: ComboRequestType.Role, request: "reaction_type");
            CreateInterfaceProperty("vt_call_message_api", "reaction_type", "Role of Attendee When Invited (API)", "REACTION_TYPE_CODE", apiEnabled: 1);

            AddColumnToProperties("vt_call_message_api", "LAST_HOST_UPDATE_DATE", "Last Host Update Date (API)", controlType: ControlType.Date, minimum: null, maximum: null, required: 0);
            CreateInterfaceProperty("vt_call_message_api", "LAST_HOST_UPDATE_DATE", "Last Host Update Date (API)", "LAST_UPDATE_DATE", apiEnabled: 1, apiReadOnly: ApiReadOnly.Always);

            AddColumnToProperties("vt_call_message_api", "event_id", "Call Identifier (API)", controlType: ControlType.Integer, minimum: null, maximum: null, required: 0);
            CreateInterfaceProperty("vt_call_message_api", "event_id", "Call Identifier (API)", "CALL_IDENTIFER", apiEnabled: 0);
            #endregion
            //add external_id_1
            #region Call Signature API
            AddEntityTable(entityName: "Call API", tableName: "vt_call_signature_api", tableType: "OM", apiTableName: "Call_Signature_API", apiEnabled: 1, apiAccess: ApiAccess.NoDelete, apiExternalIdentifier: "external_id_1");

            AddColumnToProperties("vt_call_signature_api", "event_signature_id", "Unique Identifier of Call Signature (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_call_signature_api", "event_signature_id", "Unique Identifier of Call Signature (API)", "CALL_SIGNATURE_IDENTIFIER", apiEnabled: 1,apiReadOnly: ApiReadOnly.Dynamic);

            AddColumnToProperties("vt_call_signature_api", "signature", "Signature Image (API)", controlType: ControlType.Blob, required: 1);
            CreateInterfaceProperty("vt_call_signature_api", "signature", "Signature Image (API)", "SIGNATURE_LOB", apiEnabled: 1);

            AddColumnToProperties("vt_call_signature_api", "image_type", "Type of Image Stored as (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 1, request: "event_signature/image_type", requestType: ComboRequestType.Role);
            CreateInterfaceProperty("vt_call_signature_api", "image_type", "Type of Image Stored as (API)", "IMAGE_TYPE_CODE", apiEnabled: 1);

            AddColumnToProperties("vt_call_signature_api", "signature_type", "Type of Signature", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 1, request: "event_signature/signature_type", requestType: ComboRequestType.Role);
            CreateInterfaceProperty("vt_call_signature_api", "signature_type", "Type of Signature", "SIGNATURE_TYPE_CODE", apiEnabled: 1);

            AddColumnToProperties("vt_call_signature_api", "external_id_1", "Client Call Signature Identifier (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 1);
            CreateInterfaceProperty("vt_call_signature_api", "external_id_1", "Client Call Signature Identifier (API)", "CLIENT_CALL_SIGNATURE_IDENTIFIER", apiEnabled: 1, apiReadOnly: ApiReadOnly.Immutable);

            AddColumnToProperties("vt_call_signature_api", "event_id", "Unique Identifier for Call (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_call_signature_api", "event_id", "Unique Identifier for Call (API)", "CALL_IDENTIFIER", apiEnabled: 0);

            AddColumnToProperties("vt_call_signature_api", "LAST_HOST_UPDATE_DATE", "Last Host Update Date (API)", controlType: ControlType.Date, minimum: null, maximum: null, required: 0);
            CreateInterfaceProperty("vt_call_signature_api", "LAST_HOST_UPDATE_DATE", "Last Host Update Date (API)", "LAST_UPDATE_DATE", apiEnabled: 1, apiReadOnly: ApiReadOnly.Always);
            #endregion
            #region Call Expense API
            AddEntityTable(entityName: "Call API", tableName: "vt_call_expense_api", tableType: "OM", apiTableName: "Call_Expense_API", apiEnabled: 1, apiAccess: ApiAccess.NoDelete, apiExternalIdentifier: "external_id_1");

            AddColumnToProperties("vt_call_expense_api", "event_expense_id", "Unique Identifier of Call Expense (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_call_expense_api", "event_expense_id", "Unique Identifier of Call Expense (API)", "CALL_EXPENSE_IDENTIFIER", apiEnabled: 1,apiReadOnly: ApiReadOnly.Dynamic);

            AddColumnToProperties("vt_call_expense_api", "event_expense_type", "Classification of Call Expense (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 0, requestType: ComboRequestType.Role, request: "event_expense_type");
            CreateInterfaceProperty("vt_call_expense_api", "event_expense_type", "Classification of Call Expense (API)", "EXPENSE_TYPE_CODE", apiEnabled: 1);

            AddColumnToProperties("vt_call_expense_api", "item", "Unique Item Identifier Related to Expense (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_call_expense_api", "item", "Unique Item Identifier Related to Expense (API)", "EXPENSE_ITEM_IDENTIFIER", apiEnabled: 1);

            AddColumnToProperties("vt_call_expense_api", "quantity", "Number of Items (API)", controlType: ControlType.Integer, minimum: 0, maximum: 999999999, required: 0);
            CreateInterfaceProperty("vt_call_expense_api", "quantity", "Number of Items (API)", "QUANTITY", apiEnabled: 1);

            AddColumnToProperties("vt_call_expense_api", "cost", "Cost of Item (API)", controlType: ControlType.Float, minimum: 0, maximum: 9999999999999, scale:2, required: 0);
            CreateInterfaceProperty("vt_call_expense_api", "cost", "Cost of Item (API)", "COST_AMOUNT", apiEnabled: 1);

            AddColumnToProperties("vt_call_expense_api", "vc_currency_type_code", "Currency Type (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 0,requestType: ComboRequestType.Role,request: "currency");
            CreateInterfaceProperty("vt_call_expense_api", "vc_currency_type_code", "Currency Type (API)", "CURRENCY_TYPE_CODE", apiEnabled: 1);

            AddColumnToProperties("vt_call_expense_api", "parent_key", "Foreign Key to Responsible Child Item of Expense (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_call_expense_api", "parent_key", "Foreign Key to Responsible Child Item of Expense (API)", "PARENT_CALL_EXPENSE_IDENTIFIER", apiEnabled: 1);

            AddColumnToProperties("vt_call_expense_api", "trade_secret", "Indicate If There is Trade Reason (API)", controlType: ControlType.CheckBox, required: 0);
            CreateInterfaceProperty("vt_call_expense_api", "trade_secret", "Indicate If There is Trade Reason (API)", "TRADE_SECRET_FLAG", apiEnabled: 1);

            AddColumnToProperties("vt_call_expense_api", "trade_secret_reason", "Store Trade Secret Reason (API)", controlType: ControlType.Text, minimum: 0, maximum: 2000, required: 0);
            CreateInterfaceProperty("vt_call_expense_api", "trade_secret_reason", "Store Trade Secret Reason (API)", "TRADE_SECRET_REASON_TEXT", apiEnabled: 1);

            AddColumnToProperties("vt_call_expense_api", "total_attendee_allocation", "Indicate If Entering Total Attendee Allocation (API)", controlType: ControlType.CheckBox, minimum: 0, maximum: 200, required: 0);
            CreateInterfaceProperty("vt_call_expense_api", "total_attendee_allocation", "Indicate If Entering Total Attendee Allocation (API)", "TOTAL_ATTENDEE_ALLOCATION_FLAG", apiEnabled: 1);

            AddColumnToProperties("vt_call_expense_api", "external_id_1", "Client Call Expense Identifier (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 1);
            CreateInterfaceProperty("vt_call_expense_api", "external_id_1", "Client Call Expense Identifier (API)", "CLIENT_CALL_EXPENSE_IDENTIFIER", apiEnabled: 1, apiReadOnly: ApiReadOnly.Immutable);

            AddColumnToProperties("vt_call_expense_api", "event_id", "Unique Identifier for Call (API)", controlType: ControlType.Integer, minimum: null, maximum: null, required: 0);
            CreateInterfaceProperty("vt_call_expense_api", "event_id", "Unique Identifier for Call (API)", "CALL_IDENTIFIER", apiEnabled: 0);

            AddColumnToProperties("vt_call_expense_api", "LAST_HOST_UPDATE_DATE", "Last Host Update Date (API)", controlType: ControlType.Date, minimum: null, maximum: null, required: 0);
            CreateInterfaceProperty("vt_call_expense_api", "LAST_HOST_UPDATE_DATE", "Last Host Update Date (API)", "LAST_UPDATE_DATE", apiEnabled: 1, apiReadOnly: ApiReadOnly.Always);
            #endregion
            //add external_id_1
            #region Call Expense Product API
            AddEntityTable(entityName: "Call API", tableName: "vt_call_expense_product_api", tableType: "OM", apiTableName: "Call_Expense_Product_API", apiEnabled: 1, apiAccess: ApiAccess.NoDelete, apiExternalIdentifier: "external_id_1");

            AddColumnToProperties("vt_call_expense_product_api", "event_expense_product_id", "Unique Identifier of Call Expense Product (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_call_expense_product_api", "event_expense_product_id", "Unique Identifier of Call Expense Product (API)", "CALL_EXPENSE_PRODUCT_IDENTIFIER", apiEnabled: 1);

            AddColumnToProperties("vt_call_expense_product_api", "product_id", "Unique Identifier of Product (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_call_expense_product_api", "product_id", "Unique Identifier of Product (API)", "PRODUCT_IDENTIFIER", apiEnabled: 1);

            AddColumnToProperties("vt_call_expense_product_api", "external_id_1", "Client Call Expense Product Identifier (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 1);
            CreateInterfaceProperty("vt_call_expense_product_api", "external_id_1", "Client Call Expense Product Identifier (API)", "CLIENT_CALL_EXPENSE_PRODUCT_IDENTIFIER", apiEnabled: 1, apiReadOnly: ApiReadOnly.Immutable);

            AddColumnToProperties("vt_call_expense_product_api", "event_expense_id", "Unique Identifer for Call Expense", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_call_expense_product_api", "event_expense_id", "Unique Identifer for Call Expense", "CALL_IDENTIFIER", apiEnabled: 0);

            AddColumnToProperties("vt_call_expense_product_api", "LAST_HOST_UPDATE_DATE", "Last Host Update Date (API)", controlType: ControlType.Date, minimum: null, maximum: null, required: 0);
            CreateInterfaceProperty("vt_call_expense_product_api", "LAST_HOST_UPDATE_DATE", "Last Host Update Date (API)", "LAST_UPDATE_DATE", apiEnabled: 1, apiReadOnly: ApiReadOnly.Always);
            #endregion
            #region Call Exepense Allocation API
            AddEntityTable(entityName: "Call API", tableName: "vt_call_expense_allocation_api", tableType: "OM", apiTableName: "Call_Expense_Allocation_API", apiEnabled: 1, apiAccess: ApiAccess.NoDelete, apiExternalIdentifier: "external_id_1");

            AddColumnToProperties("vt_call_expense_allocation_api", "event_expense_allocation_id", "Unique Identifier of Call Expense Allocation (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_call_expense_allocation_api", "event_expense_allocation_id", "Unique Identifier of Call Expense Allocation (API)", "CALL_EXPENSE_ALLOCATION_IDENTIFIER", apiEnabled: 1,apiReadOnly: ApiReadOnly.Dynamic);

            AddColumnToProperties("vt_call_expense_allocation_api", "entity_id", "Unique Identifier of Entity (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 1);
            CreateInterfaceProperty("vt_call_expense_allocation_api", "entity_id", "Unique Identifier of Entity (API)", "ENTITY_IDENTIFIER", apiEnabled: 1);

            AddColumnToProperties("vt_call_expense_allocation_api", "entity_type", "Entity Type (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 0,requestType: ComboRequestType.Role, request: "customer type");
            CreateInterfaceProperty("vt_call_expense_allocation_api", "entity_type", "Entity Type (API)", "ENTITY_TYPE_CODE", apiEnabled: 1);

            AddColumnToProperties("vt_call_expense_allocation_api", "name", "Name of Contact or Attendee (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 0);
            CreateInterfaceProperty("vt_call_expense_allocation_api", "name", "Name of Contact or Attendee (API)", "NAME", apiEnabled: 1);

            AddColumnToProperties("vt_call_expense_allocation_api", "title", "Position Held by Attendee (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 0);
            CreateInterfaceProperty("vt_call_expense_allocation_api", "title", "Position Held by Attendee (API)", "TITLE", apiEnabled: 1);

            AddColumnToProperties("vt_call_expense_allocation_api", "external_id_1", "Client Call Expense Allocation Identifier (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 1);
            CreateInterfaceProperty("vt_call_expense_allocation_api", "external_id_1", "Client Call Expense Allocation Identifier (API)", "CLIENT_CALL_EXPENSE_ALLOCATION_IDENTIFIER", apiEnabled: 1, apiReadOnly: ApiReadOnly.Immutable);

            AddColumnToProperties("vt_call_expense_allocation_api", "event_expense_id", "Unique Identifier for Call Expense (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_call_expense_allocation_api", "event_expense_id", "Unique Identifier for Call Expense (API)", "CALL_IDENTIFIER", apiEnabled: 0);

            AddColumnToProperties("vt_call_expense_allocation_api", "LAST_HOST_UPDATE_DATE", "Last Host Update Date (API)", controlType: ControlType.Date, minimum: null, maximum: null, required: 0);
            CreateInterfaceProperty("vt_call_expense_allocation_api", "LAST_HOST_UPDATE_DATE", "Last Host Update Date (API)", "LAST_UPDATE_DATE", apiEnabled: 1, apiReadOnly: ApiReadOnly.Always);
            #endregion
            #region Call Attendee API
            AddEntityTable(entityName: "Call API", tableName: "vt_call_attendee_api", tableType: "OM", apiTableName: "Call_Attendee_API", apiEnabled: 1, apiAccess: ApiAccess.NoDelete, apiExternalIdentifier: "external_id_1");

            AddColumnToProperties("vt_call_attendee_api", "event_attendee_id", "Unique Identifier for Call Attendee (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_call_attendee_api", "event_attendee_id", "Unique Identifier for Call Attendee (API)", "CALL_ATTENDEE_IDENTIFIER", apiEnabled: 1, apiReadOnly: ApiReadOnly.Dynamic);

            AddColumnToProperties("vt_call_attendee_api", "external_id_1", "Client Call Attendee Identifier (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 1);
            CreateInterfaceProperty("vt_call_attendee_api", "external_id_1", "Client Call Attendee Identifier (API)", "CLIENT_CALL_ATTENDEE_IDENTIFIER", apiEnabled: 1, apiReadOnly: ApiReadOnly.Immutable);

            AddColumnToProperties("vt_call_attendee_api", "customer_id", "Unique Identifier for Customer (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_call_attendee_api", "customer_id", "Unique Identifier for Customer (API)", "CUSTOMER_IDENTIFIER", apiEnabled: 1, apiReadOnly: ApiReadOnly.Dynamic);

            AddColumnToProperties("vt_call_attendee_api", "name", "Name of Attendee (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 1);
            CreateInterfaceProperty("vt_call_attendee_api", "name", "Name of Attendee (API)", "ATTENDEE_NAME", apiEnabled: 1);

            AddColumnToProperties("vt_call_attendee_api", "customer_type", "Type of Customer (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 0, requestType: ComboRequestType.Role, request: "customer type");
            CreateInterfaceProperty("vt_call_attendee_api", "customer_type", "Type of Customer (API)", "CUSTOMER_TYPE_CODE", apiEnabled: 1);

            AddColumnToProperties("vt_call_attendee_api", "customer_sub_type", "Subtype of Customer (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 0, requestType: ComboRequestType.Role, request: "specialty_1");
            CreateInterfaceProperty("vt_call_attendee_api", "customer_sub_type", "Subtype of Customer (API)", "CUSTOMER_SUBTYPE_CODE", apiEnabled: 1);

            AddColumnToProperties("vt_call_attendee_api", "comments", "Comments Noted (API)", controlType: ControlType.Text, minimum: 0, maximum: 2000, required: 0);
            CreateInterfaceProperty("vt_call_attendee_api", "comments", "Comments Noted (API)", "COMMENTS_TEXT", apiEnabled: 1);

            AddColumnToProperties("vt_call_attendee_api", "status", "Status for Call Attendee (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 1, requestType: ComboRequestType.Role, request: "event_attendee/status");
            CreateInterfaceProperty("vt_call_attendee_api", "status", "Status for Call Attendee (API)", "STATUS_CODE", apiEnabled: 1);

            AddColumnToProperties("vt_call_attendee_api", "status_change_date", "Date Status Changed (API)", controlType: ControlType.Date, defaultData: "@NOW", required: 1);
            CreateInterfaceProperty("vt_call_attendee_api", "status_change_date", "Date Status Changed (API)", "STATUS_CHANGE_DATE", apiEnabled: 1);

            AddColumnToProperties("vt_call_attendee_api", "seen", "Attendee Seen (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 0, requestType: ComboRequestType.Role, request: "call.seen");
            CreateInterfaceProperty("vt_call_attendee_api", "seen", "Attendee Seen (API)", "ATTENDEE_SEEN", apiEnabled: 1 );

            AddColumnToProperties("vt_call_attendee_api", "finish_call", "Indicate if Attendee Finished (API)", controlType: ControlType.CheckBox, minimum: 0, maximum: 200, required: 0);
            CreateInterfaceProperty("vt_call_attendee_api", "finish_call", "Indicate if Attendee Finished (API)", "ATTENDEE_CALL_FINISHED", apiEnabled: 1);
            // not call related but related to rating
            AddColumnToProperties("vt_call_attendee_api", "action_required", "Action Required (API)", controlType: ControlType.CheckBox, minimum: 0, maximum: 200, required: 0);
            CreateInterfaceProperty("vt_call_attendee_api", "action_required", "Action Required (API)", "ACTION_REQUIRED", apiEnabled: 1);

            AddColumnToProperties("vt_call_attendee_api", "reason", "Reason (API)", controlType: ControlType.Text, minimum: 0, maximum: 2000, required: 0);
            CreateInterfaceProperty("vt_call_attendee_api", "reason", "Reason (API)", "REASON_TEXT", apiEnabled: 1);

            AddColumnToProperties("vt_call_attendee_api", "event_id", "Unique Identifier for Call (API)", controlType: ControlType.Integer, minimum: null, maximum: null, required: 0);
            CreateInterfaceProperty("vt_call_attendee_api", "event_id", "Unique Identifier for Call (API)", "CALL_IDENTIFIER", apiEnabled: 0);

            AddColumnToProperties("vt_call_attendee_api", "LAST_HOST_UPDATE_DATE", "Last Host Update Date (API)", controlType: ControlType.Date, minimum: null, maximum: null, required: 0);
            CreateInterfaceProperty("vt_call_attendee_api", "LAST_HOST_UPDATE_DATE", "Last Host Update Date (API)", "LAST_UPDATE_DATE", apiEnabled: 1, apiReadOnly: ApiReadOnly.Always);
            #endregion
            #region Call Contact API
            AddEntityTable(entityName: "Call API", tableName: "vt_call_contact_api", tableType: "OM", apiTableName: "Call_Contact_API", apiEnabled: 1, apiAccess: ApiAccess.NoDelete, apiExternalIdentifier: "external_id_1");

            AddColumnToProperties("vt_call_contact_api", "event_contact_id", "Unique Identifier of Call Contact (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_call_contact_api", "event_contact_id", "Unique Identifier of Call Contact (API)", "CALL_CONTACT_IDENTIFIER", apiEnabled: 1, apiReadOnly: ApiReadOnly.Dynamic);

            AddColumnToProperties("vt_call_contact_api", "external_id_1", "Client Call Contact Identifirt (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 1);
            CreateInterfaceProperty("vt_call_contact_api", "external_id_1", "Client Call Contact Identifirt (API)", "CLIENT_CALL_CONTACT_IDENTIFIER", apiEnabled: 1, apiReadOnly: ApiReadOnly.Immutable);

            AddColumnToProperties("vt_call_contact_api", "name", "Contact Name (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 1);
            CreateInterfaceProperty("vt_call_contact_api", "name", "Contact Name (API)", "CONTACT_NAME", apiEnabled: 1);

            AddColumnToProperties("vt_call_contact_api", "title", "Title of Contact (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 0, requestType: ComboRequestType.Role, request: "staff_title");
            CreateInterfaceProperty("vt_call_contact_api", "title", "Title of Contact (API)", "CONTACT_TITLE_CODE", apiEnabled: 1);

            AddColumnToProperties("vt_call_contact_api", "comment_text", "Comments for Contact (API)", controlType: ControlType.Text, minimum: 0, maximum: 2000, required: 0);
            CreateInterfaceProperty("vt_call_contact_api", "comment_text", "Comments for Contact (API)", "COMMENTS_TEXT", apiEnabled: 1);

            AddColumnToProperties("vt_call_contact_api", "customer_staff_id", "Unique Identifirt for Customer Staff (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_call_contact_api", "customer_staff_id", "Unique Identifirt for Customer Staff (API)", "CUSTOMER_STAFF_IDENTIFIER", apiEnabled: 1);

            AddColumnToProperties("vt_call_contact_api", "customer_sub_type", "Specialty of Customer (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 0, requestType: ComboRequestType.Role, request: "specialty_1");
            CreateInterfaceProperty("vt_call_contact_api", "customer_sub_type", "Specialty of Customer (API)", "CUSTOMER_SUBTYPE_CODE", apiEnabled: 1);

            AddColumnToProperties("vt_call_contact_api", "role", "Role of Contact Person (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 0, requestType: ComboRequestType.Role, request: "affiliation_name");
            CreateInterfaceProperty("vt_call_contact_api", "role", "Role of Contact Person (API)", "ROLE_CODE", apiEnabled: 1);

            AddColumnToProperties("vt_call_contact_api", "event_id", "Unique Identifier for Call (API)", controlType: ControlType.Integer, minimum: null, maximum: null, required: 0);
            CreateInterfaceProperty("vt_call_contact_api", "event_id", "Unique Identifier for Call (API)", "CALL_IDENTIFIER", apiEnabled: 0);

            AddColumnToProperties("vt_call_contact_api", "LAST_HOST_UPDATE_DATE", "Last Host Update Date (API)", controlType: ControlType.Date, minimum: null, maximum: null, required: 0);
            CreateInterfaceProperty("vt_call_contact_api", "LAST_HOST_UPDATE_DATE", "Last Host Update Date (API)", "LAST_UPDATE_DATE", apiEnabled: 1, apiReadOnly: ApiReadOnly.Always);
            #endregion
            #region Sample Disbursement API
            AddEntityTable(entityName: "Call API", tableName: "vt_sample_disbursement_api", tableType: "OM", apiTableName: "Call_Sample_Disbursement_API", apiEnabled: 1, apiAccess: ApiAccess.NoDelete, apiExternalIdentifier: "external_id_1");

            AddColumnToProperties("vt_sample_disbursement_api", "sample_transaction_id", "Unique Identifier of Sample Disbursement (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_sample_disbursement_api", "sample_transaction_id", "Unique Identifier of Sample Disbursement (API)", "SAMPLE_DISBURSEMENT_IDENTIFIER", apiEnabled: 1,apiReadOnly: ApiReadOnly.Dynamic);

            AddColumnToProperties("vt_sample_disbursement_api", "employee_id", "Unique Identifier of Employee (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 1);
            CreateInterfaceProperty("vt_sample_disbursement_api", "employee_id", "Unique Identifier of Employee (API)", "EMPLOYEE_IDENTIFIER", apiEnabled: 1,apiReadOnly: ApiReadOnly.Dynamic);

            AddColumnToProperties("vt_sample_disbursement_api", "customer_name", "Name of Customer (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 0);
            CreateInterfaceProperty("vt_sample_disbursement_api", "customer_name", "Name of Customer (API)", "CUSTOMER_NAME", apiEnabled: 1);

            AddColumnToProperties("vt_sample_disbursement_api", "transaction_date", "Date the Transaction Occur (API)", controlType: ControlType.Date, required: 1);
            CreateInterfaceProperty("vt_sample_disbursement_api", "transaction_date", "Date the Transaction Occur (API)", "TRANSACTION_DATE", apiEnabled: 1);

            AddColumnToProperties("vt_sample_disbursement_api", "transaction_type", "Type of Transaction (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 1,requestType: ComboRequestType.Role,request: "sample_transaction/transaction_type");
            CreateInterfaceProperty("vt_sample_disbursement_api", "transaction_type", "Type of Transaction (API)", "TRANSACTION_TYPE_CODE", apiEnabled: 1);

            AddColumnToProperties("vt_sample_disbursement_api", "product_id", "Unique Identifier of Product (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 1);
            CreateInterfaceProperty("vt_sample_disbursement_api", "product_id", "Unique Identifier of Product (API)", "PRODUCT_IDENTIFIER", apiEnabled: 1,apiReadOnly: ApiReadOnly.Dynamic);

            AddColumnToProperties("vt_sample_disbursement_api", "lot_number", "Manufacture's Lot Number of Sample (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 1);
            CreateInterfaceProperty("vt_sample_disbursement_api", "lot_number", "Manufacture's Lot Number of Sample (API)", "LOT_NUMBER", apiEnabled: 1);

            AddColumnToProperties("vt_sample_disbursement_api", "physical_quantity", "Sample Product Quantity in Transaction (API)", controlType: ControlType.Integer, minimum: 0, maximum: 999999999, required: 1);
            CreateInterfaceProperty("vt_sample_disbursement_api", "physical_quantity", "Sample Product Quantity in Transaction (API)", "QUANTITY", apiEnabled: 1);

            AddColumnToProperties("vt_sample_disbursement_api", "sample_group_id", "Group Identifier of List of Transaction (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_sample_disbursement_api", "sample_group_id", "Group Identifier of List of Transaction (API)", "SAMPLE_GROUP_IDENTIFIER", apiEnabled: 1);

            AddColumnToProperties("vt_sample_disbursement_api", "entry_date", "Entry Date of Transaction (API)", controlType: ControlType.Date, required: 1);
            CreateInterfaceProperty("vt_sample_disbursement_api", "entry_date", "Entry Date of Transaction (API)", "ENTRY_DATE", apiEnabled: 1);

            AddColumnToProperties("vt_sample_disbursement_api", "check_oversampling", "Differentiate oversampling of sample transaction (API)", controlType: ControlType.CheckBox, required: 0);
            CreateInterfaceProperty("vt_sample_disbursement_api", "check_oversampling", "Differentiate oversampling of sample transaction (API)", "CHECK_OVERSAMPLING_FLAG", apiEnabled: 1);

            AddColumnToProperties("vt_sample_disbursement_api", "due_alert_date", "Due Date of Alerts (API)", controlType: ControlType.Date, required: 0);
            CreateInterfaceProperty("vt_sample_disbursement_api", "due_alert_date", "Due Date of Alerts (API)", "DUE_ALERT_DATE", apiEnabled: 1);

            AddColumnToProperties("vt_sample_disbursement_api", "start_num", "Serial Number Value (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 0);
            CreateInterfaceProperty("vt_sample_disbursement_api", "start_num", "Serial Number Value (API)", "START_NUMBER", apiEnabled: 1);

            AddColumnToProperties("vt_sample_disbursement_api", "status", "Status of Transaction (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 0,requestType: ComboRequestType.Role,request: "sample_transaction/status", defaultData: "SENT");
            CreateInterfaceProperty("vt_sample_disbursement_api", "status", "Status of Transaction (API)", "STATUS_CODE", apiEnabled: 0, apiReadOnly: ApiReadOnly.Always);

            AddColumnToProperties("vt_sample_disbursement_api", "status_change_date", "Status Change Date (API)", controlType: ControlType.Date, required: 0,defaultData: "@NOW");
            CreateInterfaceProperty("vt_sample_disbursement_api", "status_change_date", "Status Change Date (API)", "STATUS_CHANGE_DATE", apiEnabled: 0, apiReadOnly: ApiReadOnly.Always);

            AddColumnToProperties("vt_sample_disbursement_api", "external_id_1", "Client Sample Disbursement Identifier (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 1);
            CreateInterfaceProperty("vt_sample_disbursement_api", "external_id_1", "Client Sample Disbursement Identifier (API)", "CLIENT_SAMPLE_DISBURSEMENT_IDENTIFIER", apiEnabled: 1, apiReadOnly: ApiReadOnly.Immutable);

            AddColumnToProperties("vt_sample_disbursement_api", "event_id", "Unique Identifier for Call (API)", controlType: ControlType.Integer, minimum: null, maximum: null, required: 0);
            CreateInterfaceProperty("vt_sample_disbursement_api", "event_id", "Unique Identifier for Call (API)", "CALL_IDENTIFIER", apiEnabled: 0);

            AddColumnToProperties("vt_sample_disbursement_api", "LAST_HOST_UPDATE_DATE", "Last Host Update Date (API)", controlType: ControlType.Date, minimum: null, maximum: null, required: 0);
            CreateInterfaceProperty("vt_sample_disbursement_api", "LAST_HOST_UPDATE_DATE", "Last Host Update Date (API)", "LAST_UPDATE_DATE", apiEnabled: 1, apiReadOnly: ApiReadOnly.Always);
            #endregion
            #region Sample Disbursement Request API
            AddEntityTable(entityName: "Call API", tableName: "vt_sample_request_api", tableType: "OM", apiTableName: "Call_Sample_Disbursement_Request_API", apiEnabled: 1, apiAccess: ApiAccess.NoDelete, apiExternalIdentifier: "external_id_1");

            AddColumnToProperties("vt_sample_request_api", "event_sample_request_id", "Unique Identifier of Sample Request (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_sample_request_api", "event_sample_request_id", "Unique Identifier of Sample Request (API)", "SAMPLE_DISBURSEMENT_REQUEST_IDENTIFIER", apiEnabled: 1,apiReadOnly: ApiReadOnly.Dynamic);

            AddColumnToProperties("vt_sample_request_api", "product_id", "Unique Identifier of Product (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 1);
            CreateInterfaceProperty("vt_sample_request_api", "product_id", "Unique Identifier of Product (API)", "PRODUCT_IDENTIFIER", apiEnabled: 1,apiReadOnly: ApiReadOnly.Dynamic);

            AddColumnToProperties("vt_sample_request_api", "quantity", "Quantity Requested of Product (API)", controlType: ControlType.Integer, minimum: 0, maximum: 999999999, required: 1);
            CreateInterfaceProperty("vt_sample_request_api", "quantity", "Quantity Requested of Product (API)", "QUANTITY", apiEnabled: 1);

            AddColumnToProperties("vt_sample_request_api", "status", "Status of Sample Request", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 1, requestType: ComboRequestType.Role, request: "event_sample_request/status");
            CreateInterfaceProperty("vt_sample_request_api", "status", "Status of Sample Request", "STATUS_CODE", apiEnabled: 1);

            AddColumnToProperties("vt_sample_request_api", "external_id_1", "Client Sample Disbursement Request Identifier (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 1);
            CreateInterfaceProperty("vt_sample_request_api", "external_id_1", "Client Sample Disbursement Request Identifier (API)", "CLIENT_SAMPLE_DISBURSEMENT_REQUEST_IDENTIFIER", apiEnabled: 1, apiReadOnly: ApiReadOnly.Immutable);

            AddColumnToProperties("vt_sample_request_api", "event_id", "Unique Identifier for Call (API)", controlType: ControlType.Integer, minimum: null, maximum: null, required: 0);
            CreateInterfaceProperty("vt_sample_request_api", "event_id", "Unique Identifier for Call (API)", "CALL_IDENTIFIER", apiEnabled: 0);

            AddColumnToProperties("vt_sample_request_api", "LAST_HOST_UPDATE_DATE", "Last Host Update Date (API)", controlType: ControlType.Date, minimum: null, maximum: null, required: 0);
            CreateInterfaceProperty("vt_sample_request_api", "LAST_HOST_UPDATE_DATE", "Last Host Update Date (API)", "LAST_UPDATE_DATE", apiEnabled: 1, apiReadOnly: ApiReadOnly.Always);
            #endregion
            #region Call Presentation API
            AddEntityTable(entityName: "Call API", tableName: "vt_call_presentation_api", tableType: "OM", apiTableName: "Call_Presentation_API", apiEnabled: 1, apiAccess: ApiAccess.NoDelete, apiExternalIdentifier: "external_id_1");

            AddColumnToProperties("vt_call_presentation_api", "event_presentation_id", "Unqiue Identifer of Call Presentation (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_call_presentation_api", "event_presentation_id", "Unqiue Identifer of Call Presentation (API)", "CALL_PRESENTATION_IDENTIFIER", apiEnabled: 1,apiReadOnly: ApiReadOnly.Dynamic);

            AddColumnToProperties("vt_call_presentation_api", "alignment_id", "Unqiue Identifier of Sales Area (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 1);
            CreateInterfaceProperty("vt_call_presentation_api", "alignment_id", "Unqiue Identifier of Sales Area (API)", "SALES_AREA_IDENTIFIER", apiEnabled: 1, apiReadOnly: ApiReadOnly.Dynamic);

            AddColumnToProperties("vt_call_presentation_api", "employee_id", "Unique Identifier of Employee (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 1);
            CreateInterfaceProperty("vt_call_presentation_api", "employee_id", "Unique Identifier of Employee (API)", "EMPLOYEE_IDENTIFIER", apiEnabled: 1,apiReadOnly: ApiReadOnly.Dynamic);

            AddColumnToProperties("vt_call_presentation_api", "consolidated_time", "Time Spent on Presentation (API)", controlType: ControlType.Integer, minimum: 0, maximum: 999999999, required: 1);
            CreateInterfaceProperty("vt_call_presentation_api", "consolidated_time", "Time Spent on Presentation (API)", "CONSOLIDATED_TIME_NUMBER", apiEnabled: 1);

            AddColumnToProperties("vt_call_presentation_api", "status", "Status of Played Presentation (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 0,requestType: ComboRequestType.Role, request: "active.inactive");
            CreateInterfaceProperty("vt_call_presentation_api", "status", "Status of Played Presentation (API)", "STATUS_CODE", apiEnabled: 1);

            AddColumnToProperties("vt_call_presentation_api", "presentation_name", "Descriptive Name of Presentation (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 0);
            CreateInterfaceProperty("vt_call_presentation_api", "presentation_name", "Descriptive Name of Presentation (API)", "PRESENTATION_NAME", apiEnabled: 1);

            AddColumnToProperties("vt_call_presentation_api", "reaction_type", "Reaction Type of Presentation (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 0, requestType: ComboRequestType.Role, request: "event_detail/reaction_type");
            CreateInterfaceProperty("vt_call_presentation_api", "reaction_type", "Reaction Type of Presentation (API)", "REACTION_TYPE_CODE", apiEnabled: 1);
            CreateDropDown("vt_call_presentation_api", "reaction_type", "POSI,NONE,NEGA", "Positive,Neutral,Negative");

            AddColumnToProperties("vt_call_presentation_api", "context", "Context of Presentation (API)", controlType: ControlType.Blob, required: 0);
            CreateInterfaceProperty("vt_call_presentation_api", "context", "Context of Presentation (API)", "CONTEXT_LOB", apiEnabled: 1);

            AddColumnToProperties("vt_call_presentation_api", "external_id_1", "Client Call Presentation Identifier (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 1);
            CreateInterfaceProperty("vt_call_presentation_api", "external_id_1", "Client Call Presentation Identifier (API)", "CLIENT_CALL_PRESENTATION_IDENTIFIER", apiEnabled: 1, apiReadOnly: ApiReadOnly.Immutable);

            AddColumnToProperties("vt_call_presentation_api", "event_id", "Unique Identifier for Call (API)", controlType: ControlType.Integer, minimum: null, maximum: null, required: 0);
            CreateInterfaceProperty("vt_call_presentation_api", "event_id", "Unique Identifier for Call (API)", "CALL_IDENTIFIER", apiEnabled: 0);

            AddColumnToProperties("vt_call_presentation_api", "LAST_HOST_UPDATE_DATE", "Last Host Update Date (API)", controlType: ControlType.Date, minimum: null, maximum: null, required: 0);
            CreateInterfaceProperty("vt_call_presentation_api", "LAST_HOST_UPDATE_DATE", "Last Host Update Date (API)", "LAST_UPDATE_DATE", apiEnabled: 1, apiReadOnly: ApiReadOnly.Always);
            #endregion
            #region Call Presentation Detail API
            AddEntityTable(entityName: "Call API", tableName: "vt_presentation_detail_api", tableType: "OM", apiTableName: "Call_Presentation_Detail_API", apiEnabled: 1, apiAccess: ApiAccess.NoDelete, apiExternalIdentifier: "external_id_1");

            AddColumnToProperties("vt_presentation_detail_api", "event_presentation_detail_id", "Unique Identifier of Presentation Detail (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_presentation_detail_api", "event_presentation_detail_id", "Unique Identifier of Presentation Detail (API)", "CALL_PRESENTATION_DETAIL_IDENTIFIER", apiEnabled: 1,apiReadOnly: ApiReadOnly.Dynamic);

            AddColumnToProperties("vt_presentation_detail_api", "detailed_time", "Time Spent on Given Action (API)", controlType: ControlType.Integer, minimum: 0, maximum: 999999999, required: 1);
            CreateInterfaceProperty("vt_presentation_detail_api", "detailed_time", "Time Spent on Given Action (API)", "DETAILED_TIME", apiEnabled: 1);

            AddColumnToProperties("vt_presentation_detail_api", "action", "Action (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 1,requestType: null, defaultData: "PLAY", request: null);
            CreateInterfaceProperty("vt_presentation_detail_api", "action", "Action (API)", "ACTION", apiEnabled: 1);

            AddColumnToProperties("vt_presentation_detail_api", "from_time", "Start Time of Given Action (API)", controlType: ControlType.Integer, minimum: 0, maximum: 999999999, required: 0);
            CreateInterfaceProperty("vt_presentation_detail_api", "from_time", "Start Time of Given Action (API)", "FROM_TIME", apiEnabled: 1);

            AddColumnToProperties("vt_presentation_detail_api", "to_time", "End Time of Given Action (API)", controlType: ControlType.Integer, minimum: 0, maximum: 999999999, required: 0);
            CreateInterfaceProperty("vt_presentation_detail_api", "to_time", "End Time of Given Action (API)", "TO_TIME", apiEnabled: 1);

            AddColumnToProperties("vt_presentation_detail_api", "product_id", "Unique Identifier of Product (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_presentation_detail_api", "product_id", "Unique Identifier of Product (API)", "PRODUCT_IDENTIFIER", apiEnabled: 1,apiReadOnly: ApiReadOnly.Dynamic);

            AddColumnToProperties("vt_presentation_detail_api", "page", "Page (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 0);
            CreateInterfaceProperty("vt_presentation_detail_api", "page", "Page (API)", "PAGE", apiEnabled: 1);

            AddColumnToProperties("vt_presentation_detail_api", "message_id", "Unique Identifier of Product Message (API)", controlType: ControlType.Integer, minimum: 0, maximum: 9999999999999999, required: 0);
            CreateInterfaceProperty("vt_presentation_detail_api", "message_id", "Unique Identifier of Product Message (API)", "PRODUCT_MESSAGE_IDENTIFIER", apiEnabled: 1);

            AddColumnToProperties("vt_presentation_detail_api", "slide_order", "Order of Presentation Slide (API)", controlType: ControlType.Integer, minimum: 0, maximum: 999999999, required: 0);
            CreateInterfaceProperty("vt_presentation_detail_api", "slide_order", "Order of Presentation Slide (API)", "SLIDE_ORDER", apiEnabled: 1);

            AddColumnToProperties("vt_presentation_detail_api", "category", "Category of Presentation Slide (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 0,requestType: ComboRequestType.TableColumn);
            CreateInterfaceProperty("vt_presentation_detail_api", "category", "Category of Presentation Slide (API)", "CATEGORY", apiEnabled: 1);

            AddColumnToProperties("vt_presentation_detail_api", "reaction_type", "Customer Reaction (API)", controlType: ControlType.DropDown, minimum: 0, maximum: 200, required: 0,requestType: ComboRequestType.Role, request: "event_detail/reaction_type");
            CreateInterfaceProperty("vt_presentation_detail_api", "reaction_type", "Customer Reaction (API)", "REACTION_TYPE_CODE", apiEnabled: 1);

            AddColumnToProperties("vt_presentation_detail_api", "questions_raised", "Indicate If Question is Raised (API)", controlType: ControlType.CheckBox, required: 0);
            CreateInterfaceProperty("vt_presentation_detail_api", "questions_raised", "Indicate If Question is Raised (API)", "QUESTIONS_RAISED_FLAG", apiEnabled: 1);

            AddColumnToProperties("vt_presentation_detail_api", "external_id_1", "Client Call Presentation Detail Identifier (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 1);
            CreateInterfaceProperty("vt_presentation_detail_api", "external_id_1", "Client Call Presentation Detail Identifier (API)", "CLIENT_CALL_PRESENTATION_DETAIL_IDENTIFIER", apiEnabled: 1, apiReadOnly: ApiReadOnly.Immutable);

            AddColumnToProperties("vt_presentation_detail_api", "event_presentation_id", "Unique Identifier for Call Presentation (API)", controlType: ControlType.Integer, minimum: null, maximum: null, required: 0);
            CreateInterfaceProperty("vt_presentation_detail_api", "event_presentation_id", "Unique Identifier for Call Presentation (API)", "CALL_IDENTIFIER", apiEnabled: 0);

            AddColumnToProperties("vt_presentation_detail_api", "LAST_HOST_UPDATE_DATE", "Last Host Update Date (API)", controlType: ControlType.Date, minimum: null, maximum: null, required: 0);
            CreateInterfaceProperty("vt_presentation_detail_api", "LAST_HOST_UPDATE_DATE", "Last Host Update Date (API)", "LAST_UPDATE_DATE", apiEnabled: 1, apiReadOnly: ApiReadOnly.Always);
            #endregion
            #region Call Presentation Asset API
            AddEntityTable(entityName: "Call API", tableName: "vt_presentation_asset_api", tableType: "OM", apiTableName: "Call_Presentation_Asset_API", apiEnabled: 1, apiAccess: ApiAccess.NoDelete, apiExternalIdentifier: "external_id_1");

            AddColumnToProperties("vt_presentation_asset_api", "event_presentation_asset_id", "Unique Identifier of Presentation Asset (API)", controlType: ControlType.Integer, minimum: long.MinValue, maximum: long.MaxValue, required: 0);
            CreateInterfaceProperty("vt_presentation_asset_api", "event_presentation_asset_id", "Unique Identifier of Presentation Asset (API)", "CALL_PRESENTATION_ASSET_IDENTIFIER", apiEnabled: 1,apiReadOnly: ApiReadOnly.Dynamic);

            AddColumnToProperties("vt_presentation_asset_api", "start_date_time", "Asset Start Date Time (API)", controlType: ControlType.Date, minimum: 0, maximum: 200, required: 0);
            CreateInterfaceProperty("vt_presentation_asset_api", "start_date_time", "Asset Start Date Time (API)", "START_DATE_TIME", apiEnabled: 1);

            AddColumnToProperties("vt_presentation_asset_api", "duration", "Total Duration of Visiting Asset (API)", controlType: ControlType.Integer, minimum: 0, maximum: 999999999, required: 1);
            CreateInterfaceProperty("vt_presentation_asset_api", "duration", "Total Duration of Visiting Asset (API)", "DURATION", apiEnabled: 1);

            AddColumnToProperties("vt_presentation_asset_api", "description", "Description of Asset (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 0);
            CreateInterfaceProperty("vt_presentation_asset_api", "description", "Description of Asset (API)", "DESCRIPTION", apiEnabled: 1);

            AddColumnToProperties("vt_presentation_asset_api", "external_id_1", "Client Call Presentation Asset Identifier (API)", controlType: ControlType.Text, minimum: 0, maximum: 200, required: 1);
            CreateInterfaceProperty("vt_presentation_asset_api", "external_id_1", "Client Call Presentation Asset Identifier (API)", "CLIENT_CALL_PRESENTATION_ASSET_IDENTIFIER", apiEnabled: 1, apiReadOnly: ApiReadOnly.Immutable);

            AddColumnToProperties("vt_presentation_asset_api", "event_presentation_detail_id", "Unique Identifier for Call (API)", controlType: ControlType.Integer, minimum: null, maximum: null, required: 0);
            CreateInterfaceProperty("vt_presentation_asset_api", "event_presentation_detail_id", "Unique Identifier for Call (API)", "CALL_IDENTIFIER", apiEnabled: 0);

            AddColumnToProperties("vt_presentation_asset_api", "LAST_HOST_UPDATE_DATE", "Last Host Update Date (API)", controlType: ControlType.Date, minimum: null, maximum: null, required: 0);
            CreateInterfaceProperty("vt_presentation_asset_api", "LAST_HOST_UPDATE_DATE", "Last Host Update Date (API)", "LAST_UPDATE_DATE", apiEnabled: 1, apiReadOnly: ApiReadOnly.Always);
            #endregion
            #region Plugins
            RegisterNamedPlugin(pluginName: "APICallPlugIn", pluginType: "BusinessObjectPlugin",
                pluginClass: "Dendrite.WebForce.MobileComponents.Plugins.Event.API.APICallPlugIn, Dendrite.WebForce.MobileComponents");
            AddEntityBOPlugin(entityName: "Call API", pluginType: "PLUG", pluginName: "APICallPlugIn", apiFlags: ApiAccess.NoDelete);
            #endregion
            #region DN_DATE_ENGINE
            AddDataEngineTable(applicationCode: "WF4", tblName: "vt_call_api", tblAttributes: "copy^event^filter^vt_call_api.event_type='C'^allow_updates^true");

            AddDataEngineColumn(applicationCode: "WF4", colTable: "vt_call_api", colName: "vc_entity_type", colAttributes: "type^CHAR");

            AddDataEngineColumn(applicationCode: "WF4", colTable: "vt_call_api", colName: "vc_sales_area_amount", colAttributes: "type^NUMBER");

            AddDataEngineColumn(applicationCode: "WF4", colTable: "vt_call_api", colName: "vc_sales_force_name", colAttributes: "type^CHAR");

            AddDataEngineColumn(applicationCode: "WF4", colTable: "vt_call_api", colName: "vc_state_license_state_name", colAttributes: "type^CHAR");

            AddDataEngineColumn(applicationCode: "WF4", colTable: "vt_call_api", colName: "vc_state_license_expiration_date", colAttributes: "type^DATE");

            AddDataEngineColumn(applicationCode: "WF4", colTable: "vt_call_api", colName: "vc_dea_number_identifier", colAttributes: "type^CHAR^join^affiliation.exteranl_id_1^optional^Y");

            AddDataEngineColumn(applicationCode: "WF4", colTable: "vt_call_api", colName: "vc_dea_expiration_date", colAttributes: "type^DATE^join^affiliation.external_id_1_date^optional^Y");

            AddDataEngineColumn(applicationCode: "WF4", colTable: "vt_call_api", colName: "vc_sampling_status_code", colAttributes: "type^CHAR^join^customer.sampling_status^optional^Y");

            AddDataEngineColumn(applicationCode: "WF4", colTable: "vt_call_api", colName: "vc_professional_suffix_code", colAttributes: "type^CHAR^join^person.suffix^optional^Y");

            AddDataEngineColumn(applicationCode: "WF4", colTable: "vt_call_api", colName: "vc_address_identifier", colAttributes: "type^CHAR^join^vt_call_address_api.address_id^optional^Y");

            AddDataEngineColumn(applicationCode: "WF4", colTable: "vt_call_api", colName: "vc_address_line1", colAttributes: "type^CHAR^join^vt_call_address_api.line_1_address^optional^Y");

            AddDataEngineColumn(applicationCode: "WF4", colTable: "vt_call_api", colName: "vc_address_line2", colAttributes: "type^CHAR^join^vt_call_address_api.line_2_address^optional^Y");

            AddDataEngineColumn(applicationCode: "WF4", colTable: "vt_call_api", colName: "vc_address_line3", colAttributes: "type^CHAR^join^vt_call_address_api.line_3_address^optional^Y");

            AddDataEngineColumn(applicationCode: "WF4", colTable: "vt_call_api", colName: "vc_city_name", colAttributes: "type^CHAR^join^vt_call_address_api.city^optional^Y");

            AddDataEngineColumn(applicationCode: "WF4", colTable: "vt_call_api", colName: "vc_region_name", colAttributes: "type^CHAR^join^vt_call_address_api.state^optional^Y");

            AddDataEngineColumn(applicationCode: "WF4", colTable: "vt_call_api", colName: "vc_postal_area", colAttributes: "type^CHAR^join^vt_call_address_api.postal_area^optional^Y");

            AddDataEngineColumn(applicationCode: "WF4", colTable: "vt_call_api", colName: "vc_postal_area_extension", colAttributes: "type^CHAR");

            AddDataEngineColumn(applicationCode: "WF4", colTable: "vt_call_api", colName: "vc_organization_name", colAttributes: "type^CHAR^join^vt_call_address_api.to_name^optional^Y");

            AddDataEngineColumn(applicationCode: "WF4", colTable: "vt_call_api", colName: "vc_org_address_line1", colAttributes: "type^CHAR");

            AddDataEngineColumn(applicationCode: "WF4", colTable: "vt_call_api", colName: "vc_org_address_line2", colAttributes: "type^CHAR");

            AddDataEngineColumn(applicationCode: "WF4", colTable: "vt_call_api", colName: "vc_org_address_line3", colAttributes: "type^CHAR");

            AddDataEngineColumn(applicationCode: "WF4", colTable: "vt_call_api", colName: "vc_org_city_name", colAttributes: "type^CHAR");

            AddDataEngineColumn(applicationCode: "WF4", colTable: "vt_call_api", colName: "vc_org_region_name", colAttributes: "type^CHAR");

            AddDataEngineColumn(applicationCode: "WF4", colTable: "vt_call_api", colName: "vc_org_postal_area", colAttributes: "type^CHAR");

            AddDataEngineColumn(applicationCode: "WF4", colTable: "vt_call_api", colName: "vc_org_postal_area_extension", colAttributes: "type^CHAR");

            AddDataEngineColumn(applicationCode: "WF4", colTable: "vt_call_api", colName: "vc_org_country_code", colAttributes: "type^CHAR^join^vt_call_address_api.country^optional^Y");

            AddDataEngineColumn(applicationCode: "WF4", colTable: "vt_call_api", colName: "vc_disbursement_type_code", colAttributes: "type^CHAR");

            AddDataEngineColumn(applicationCode: "WF4", colTable: "vt_call_api", colName: "vc_region_identifier", colAttributes: "type^CHAR");

            AddDataEngineColumn(applicationCode: "WF4", colTable: "vt_call_api", colName: "vc_business_unit_identifier", colAttributes: "type^CHAR");

            AddDataEngineColumn(applicationCode: "WF4", colTable: "vt_call_api", colName: "vc_customer_sales_area_cycle_code", colAttributes: "type^CHAR");

            //TODO: add Table Link
            #endregion
            #region Codes

            ////CreateDropDownCodeRole("call", "call_type_code", "call.type");
            //AddCodeRole("call.type", "", "");
            //AppendNewRoleCode("call.type", "ADV", "ADV Call");
            //AppendNewRoleCode("call.type", "A", "Appointment");
            //AppendNewRoleCode("call.type", "C", "Call");
            //AppendNewRoleCode("call.type", "Q", "Quick Sign");
            ////CreateDropDownCodeRole("call", "call_status_code", "call.status");
            AddCodeRole("call.status", "", "");
            AppendNewRoleCode("call.status", "OPEN", "Open");
            AppendNewRoleCode("call.status", "LCKD", "Locked");
            AddCodeRole("call.seen", "", "");
            AppendNewRoleCode("call.seen", "True", "True");
            ////CreateDropDownCodeRole("call", "call_subtype_code", "call.subtype");
            //AddCodeRole("call.subtype", "", "");
            //AppendNewRoleCode("call.subtype", "AO", "Activity Only");
            //AppendNewRoleCode("call.subtype", "AS", "Activity and Sample");
            //AppendNewRoleCode("call.subtype", "DS", "Detail And Sample");
            //AppendNewRoleCode("call.subtype", "DO", "Detail Only");
            //AppendNewRoleCode("call.subtype", "DA", "Detail and Activity");
            //AppendNewRoleCode("call.subtype", "DAS", "Detail, Activity and Sample");
            //AppendNewRoleCode("call.subtype", "DM", "Dinner Meeting");
            //AppendNewRoleCode("call.subtype", "EX", "Exhibition");
            //AppendNewRoleCode("call.subtype", "GS", "Group Sell");
            //AppendNewRoleCode("call.subtype", "HO", "Hospital Meeting");
            //AppendNewRoleCode("call.subtype", "LN", "Lunch Meeting");
            //AppendNewRoleCode("call.subtype", "OT", "Other");
            //AppendNewRoleCode("call.subtype", "RC", "Remote Call");
            //AppendNewRoleCode("call.subtype", "RT", "Retailer Meeting");
            //AppendNewRoleCode("call.subtype", "SO", "Sample Only");
            ////CreateDropDownCodeRole("call", "sampling_status_code", "call.sampling_status");
            //AddCodeRole("call.sampling_status", "", "");
            //AppendNewRoleCode("call.sampling_status", "ACKN", "Acknowledged");
            //AppendNewRoleCode("call.sampling_status", "ALWD", "Allowed");
            //AppendNewRoleCode("call.sampling_status", "DEND", "Denied");
            //AppendNewRoleCode("call.sampling_status", "PEND", "Pending");
            ////CreateDropDownCodeRole("call", "professional_suffix_code", "call.prof_suffix");
            //AddCodeRole("call.prof_suffix", "", "");
            //AppendNewRoleCode("call.prof_suffix", "MB", "Bachelor of Medicine");
            //AppendNewRoleCode("call.prof_suffix", "CNM", "Certified Nurse-Midwife");
            //AppendNewRoleCode("call.prof_suffix", "CRNA", "Certified Registered Nurse Anesthetist");
            //AppendNewRoleCode("call.prof_suffix", "DO", "DO");
            //AppendNewRoleCode("call.prof_suffix", "IM", "IM");
            //AppendNewRoleCode("call.prof_suffix", "MD", "MD");
            //AppendNewRoleCode("call.prof_suffix", "MA", "Master of Arts");
            //AppendNewRoleCode("call.prof_suffix", "MSN", "Master of Science in Nursing");
            //AppendNewRoleCode("call.prof_suffix", "MS", "Master of Surgery");
            //AppendNewRoleCode("call.prof_suffix", "NP", "NP");
            //AppendNewRoleCode("call.prof_suffix", "PA", "PA");
            //AppendNewRoleCode("call.prof_suffix", "PD", "PD");
            //AppendNewRoleCode("call.prof_suffix", "PHD", "PhD");
            //AppendNewRoleCode("call.prof_suffix", "PRD", "PharmD");
            //AppendNewRoleCode("call.prof_suffix", "RPH", "RPH");
            ////CreateDropDownCodeRole("call", "org_country_code", "call.country");
            ////AddCodeRole("call.country", "", "");
            ////AppendNewRoleCode("call.country", "ISO country codes", "ISO");
            ////CreateDropDownCodeRole("call", "contact_type_code", "call.contact_type");
            //AddCodeRole("call.contact_type", "", "");
            //AppendNewRoleCode("call.contact_type", "DO", "Detail Only");
            //AppendNewRoleCode("call.contact_type", "DM", "Dinner Meeting");
            //AppendNewRoleCode("call.contact_type", "EM", "EMail");
            //AppendNewRoleCode("call.contact_type", "EX", "Exhibition");
            //AppendNewRoleCode("call.contact_type", "FF", "Face-to-Face");
            //AppendNewRoleCode("call.contact_type", "FX", "Fax");
            //AppendNewRoleCode("call.contact_type", "GM", "General Meeting");
            //AppendNewRoleCode("call.contact_type", "GS", "Group Sell");
            //AppendNewRoleCode("call.contact_type", "HO", "Institution Meeting");
            //AppendNewRoleCode("call.contact_type", "LN", "Lunch Meeting");
            //AppendNewRoleCode("call.contact_type", "OT", "Other");
            //AppendNewRoleCode("call.contact_type", "PH", "Phone");
            //AppendNewRoleCode("call.contact_type", "RT", "Retailer Meeting");
            //CreateDropDownCodeRole("call", "audience_code", "call.audience");
            //AddCodeRole("call.audience", "", "");
            //AppendNewRoleCode("call.audience", "AUC1", "Example Code");
            ////CreateDropDownCodeRole("call", "not_visited_reason_code", "call.not_visit_reason");
            //AddCodeRole("call.not_visit_reason", "", "");
            //AppendNewRoleCode("call.not_visit_reason", "NVRC", "Not Visited reason Code, Example Code");
            ////CreateDropDownCodeRole("call", "business_issue_code", "call.business_iisue");
            //AddCodeRole("call.business_issue", "", "");
            //AppendNewRoleCode("call.business_issue", "BIC1", "Business Issue Code example");
            ////CreateDropDownCodeRole("call", "buying_cycle_code", "call.buying_cycle");
            //AddCodeRole("call.buying_cycle", "", "");
            //AppendNewRoleCode("call.buying_cycle", "C1", "Cycle One");
            //AppendNewRoleCode("call.buying_cycle", "C2", "Cycle Two");
            //AppendNewRoleCode("call.buying_cycle", "C3", "Cycle Three");
            //AppendNewRoleCode("call.buying_cycle", "C4", "Cycle Four");
            //CreateDropDownCodeRole("call", "accompanied_by_code", "call.accompanied_by");
            //AddCodeRole("call.accompanied_by", "", "");
            //AppendNewRoleCode("call.accompanied_by", "DM", "District Manager");
            //AppendNewRoleCode("call.accompanied_by", "FT", "Field Trainer");
            //AppendNewRoleCode("call.accompanied_by", "RM", "Regional Manager");
            //CreateDropDownCodeRole("call", "disbursement_type_code", "call.disbursement_type");
            AddCodeRole("call.disbursement_type", "", "");
            AppendNewRoleCode("call.disbursement_type", "LE", "Legal");
            AppendNewRoleCode("call.disbursement_type", "MAT", "Match");
            //CreateDropDownCodeRole("call", "appointment_type_code", "call.appointment_type");
            //AddCodeRole("call.appointment_type", "", "");
            //AppendNewRoleCode("call.appointment_type", "A", "Appointment");
            //AppendNewRoleCode("call.appointment_type", "D", "Drop-in");
            //AppendNewRoleCode("call.appointment_type", "P", "Programmed Call");
            //AppendNewRoleCode("call.appointment_type", "S", "System generated");
            //CreateDropDownCodeRole("call", "purpose_code", "call.purpose");
            //AddCodeRole("call.purpose", "", "");
            //AppendNewRoleCode("call.purpose", "DETL", "Detail");
            //AppendNewRoleCode("call.purpose", "DS", "Detail And Sample");
            //AppendNewRoleCode("call.purpose", "DO", "Detail Only");
            //AppendNewRoleCode("call.purpose", "DA", "Detail and Activity");
            //AppendNewRoleCode("call.purpose", "DAS", "Detail, Activity and Sample");
            //AppendNewRoleCode("call.purpose", "INTR", "Introduction");
            //AppendNewRoleCode("call.purpose", "MMPT", "Multimedia Presentation");
            //AppendNewRoleCode("call.purpose", "NEGO", "Negotiation");
            //AppendNewRoleCode("call.purpose", "ORDR", "Ordering");
            //AppendNewRoleCode("call.purpose", "OT", "Other");
            //AppendNewRoleCode("call.purpose", "PRMO", "Promotion");
            //AppendNewRoleCode("call.purpose", "SO", "Sample Only");
            ////CreateDropDownCodeRole("call", "interaction_channel_code", "call.interaction_channel");
            //AddCodeRole("call.interaction_channel", "", "");
            //AppendNewRoleCode("call.interaction_channel", "EML", "Email");
            //AppendNewRoleCode("call.interaction_channel", "INPR", "Face To Face");
            //AppendNewRoleCode("call.interaction_channel", "FAX", "Fax");
            //AppendNewRoleCode("call.interaction_channel", "INPR", "In Person");
            //AppendNewRoleCode("call.interaction_channel", "MAIL", "Mail");
            //AppendNewRoleCode("call.interaction_channel", "PHON", "Phone");
            //AppendNewRoleCode("call.interaction_channel", "EDE", "Remote Detailing");
            //AppendNewRoleCode("call.interaction_channel", "WEB", "Web");
            //AppendNewRoleCode("call.interaction_channel", "EC", "eDetailing Call");
            ////CreateDropDownCodeRole("call", "owner_confirm_status_code", "call.owner_confirm_status");
            //AddCodeRole("call.owner_confirm_status", "", "");
            //AppendNewRoleCode("call.owner_confirm_status", "CHKD", "Checked");
            //AppendNewRoleCode("call.owner_confirm_status", "NONE", "NONE");
            //AppendNewRoleCode("call.owner_confirm_status", "RQST", "Requested to Check");
            ////CreateDropDownCodeRole("call", "manager_confirm_status_code", "call.manager_confirm_status");
            //AddCodeRole("call.manager_confirm_status", "", "");
            //AppendNewRoleCode("call.manager_confirm_status", "CHKD", "Checked");
            //AppendNewRoleCode("call.manager_confirm_status", "NONE", "NONE");
            //AppendNewRoleCode("call.manager_confirm_status", "RQST", "Requested to Check");
            ////CreateDropDownCodeRole("call", "source_code", "call.source");
            //AddCodeRole("call.source", "", "");
            //AppendNewRoleCode("call.source", "CLI", "Client Dataload");
            //AppendNewRoleCode("call.source", "CDMI", "Mobile Intelligence");
            ////CreateDropDownCodeRole("call_detail", "indication_code", "call_detail.indication");
            //AddCodeRole("call_detail.indication", "", "");
            //AppendNewRoleCode("call_detail.indication", "NEGA", "Negative");
            //AppendNewRoleCode("call_detail.indication", "NONE", "None");
            //AppendNewRoleCode("call_detail.indication", "POSI", "Positive");
            ////CreateDropDownCodeRole("call_detail", "call_detail_status_code", "cal_detail.status");
            ////AddCodeRole("cal_detail.status", "", "");
            ////AppendNewRoleCode("cal_detail.status", "OPEN", "Open");
            ////AppendNewRoleCode("cal_detail.status", "LCKD", "Locked");
            ////CreateDropDownCodeRole("call_signature", "image_type_code", "call_signature.image_type");
            //AddCodeRole("call_signature.image_type", "", "");
            //AppendNewRoleCode("call_signature.image_type", "BMP", "Bitmap (BMP)");
            //AppendNewRoleCode("call_signature.image_type", "GIF", "Graphics Interchange Format (GIF)");
            //AppendNewRoleCode("call_signature.image_type", "JPEG", "Joint Photographic Experts Group (JPEG)");
            //AppendNewRoleCode("call_signature.image_type", "PNG", "Portable Network Graphics (PNG)");
            //AppendNewRoleCode("call_signature.image_type", "TIFF", "Tagged Image File Format (TIFF)");
            ////CreateDropDownCodeRole("call_signature", "signature_type_code", "call_signaturesignature_type");
            //AddCodeRole("call_signature.signature_type", "", "");
            //AppendNewRoleCode("call_signature.signature_type", "DRPP", "Drop with Paper Signature");
            //AppendNewRoleCode("call_signature.signature_type", "QSGN", "Quick Sign Signature");
            //AppendNewRoleCode("call_signature.signature_type", "DROP", "Sample Drop Signature");
            ////CreateDropDownCodeRole("call_expense", "expense_type_code", "call_expense.type");
            //AddCodeRole("call_expense.type", "", "");
            //AppendNewRoleCode("call_expense.type", "ENTE", "Entertainment Expenses");
            //AppendNewRoleCode("call_expense.type", "FOOD", "Food(Meal) Beverages");
            //AppendNewRoleCode("call_expense.type", "GIFT", "Gift /Promo Item");
            //AppendNewRoleCode("call_expense.type", "OTHR", "Other");
            ////CreateDropDownCodeRole("call_expense", "currency_type_code", "call_expense.currency");
            //AddCodeRole("call_expense.currency", "", "");
            //AppendNewRoleCode("call_expense.currency", "ATS", "Austria, Schilling");
            //AppendNewRoleCode("call_expense.currency", "BEF", "Belgium, Franc");
            //AppendNewRoleCode("call_expense.currency", "CNY", "Chinese, Yuan");
            //AppendNewRoleCode("call_expense.currency", "EURO", "Euro");
            //AppendNewRoleCode("call_expense.currency", "FIM", "Finland, Markka");
            //AppendNewRoleCode("call_expense.currency", "FRF", "France, Franc");
            //AppendNewRoleCode("call_expense.currency", "DEM", "Germany, Deutsche Mark");
            //AppendNewRoleCode("call_expense.currency", "IEP", "Ireland, Punt");
            //AppendNewRoleCode("call_expense.currency", "ITL", "Italy, Lira");
            //AppendNewRoleCode("call_expense.currency", "JPN", "Japanese, Yen");
            //AppendNewRoleCode("call_expense.currency", "KRW", "Korea, Won");
            //AppendNewRoleCode("call_expense.currency", "LUF", "Luxembourg, Franc");
            //AppendNewRoleCode("call_expense.currency", "PTE", "Portugal, Escudo");
            //AppendNewRoleCode("call_expense.currency", "SGD", "Singapore, Dollar");
            //AppendNewRoleCode("call_expense.currency", "ESP", "Spain, Peseta");
            //AppendNewRoleCode("call_expense.currency", "NLG", "The Netherlands, Dutch Guilder");
            //AppendNewRoleCode("call_expense.currency", "USD", "US, Dollar");
            ////CreateDropDownCodeRole("call_expense_allocation", "entity_type_code", "call_expense_allocation.entity_type");
            //AddCodeRole("call_expense_allocation.entity_type", "", "");
            //AppendNewRoleCode("call_expense_allocation.entity_type", "VET", "AH Individual");
            //AppendNewRoleCode("call_expense_allocation.entity_type", "VINS", "AH Organization");
            //AppendNewRoleCode("call_expense_allocation.entity_type", "ACNT", "Account");
            //AppendNewRoleCode("call_expense_allocation.entity_type", "NPRS", "Business Contact");
            //AppendNewRoleCode("call_expense_allocation.entity_type", "CLUS", "Cluster");
            //AppendNewRoleCode("call_expense_allocation.entity_type", "CONS", "Consumer");
            //AppendNewRoleCode("call_expense_allocation.entity_type", "CUST", "Customer");
            //AppendNewRoleCode("call_expense_allocation.entity_type", "DEPT", "Department");
            //AppendNewRoleCode("call_expense_allocation.entity_type", "ENTY", "Entity");
            //AppendNewRoleCode("call_expense_allocation.entity_type", "FORM", "Formulary");
            //AppendNewRoleCode("call_expense_allocation.entity_type", "GRC1", "Generic Entity 1");
            //AppendNewRoleCode("call_expense_allocation.entity_type", "GPO", "Group Purchasing Organization");
            //AppendNewRoleCode("call_expense_allocation.entity_type", "HGRP", "Hospital Group");
            //AppendNewRoleCode("call_expense_allocation.entity_type", "HOSP", "Institution");
            //AppendNewRoleCode("call_expense_allocation.entity_type", "IDN", "Integrated Delivery Network");
            //AppendNewRoleCode("call_expense_allocation.entity_type", "IHS", "Integrated Healthcare System");
            //AppendNewRoleCode("call_expense_allocation.entity_type", "PRES", "KOL");
            //AppendNewRoleCode("call_expense_allocation.entity_type", "PRES", "KOL/Contact");
            //AppendNewRoleCode("call_expense_allocation.entity_type", "VET", "KOL/Contact");
            //AppendNewRoleCode("call_expense_allocation.entity_type", "MCO", "Managed Care Organization");
            //AppendNewRoleCode("call_expense_allocation.entity_type", "PRES", "Medical Professional");
            //AppendNewRoleCode("call_expense_allocation.entity_type", "HOSP", "Organization");
            //AppendNewRoleCode("call_expense_allocation.entity_type", "VINS", "Organization");
            //AppendNewRoleCode("call_expense_allocation.entity_type", "OENT", "Other Entity");
            //AppendNewRoleCode("call_expense_allocation.entity_type", "PHAR", "Pharmacy");
            //AppendNewRoleCode("call_expense_allocation.entity_type", "PBM", "Pharmacy Benefits Manager");
            //AppendNewRoleCode("call_expense_allocation.entity_type", "GRP", "Practice");
            //AppendNewRoleCode("call_expense_allocation.entity_type", "VET", "Veterinarian");
            //AppendNewRoleCode("call_expense_allocation.entity_type", "VINS", "Veterinary Institution");
            //AppendNewRoleCode("call_expense_allocation.entity_type", "WHOL", "Wholesaler");
            ////CreateDropDownCodeRole("sample_disbursement", "transaction_type_code", "sample_disbursement.transaction_type");
            //AddCodeRole("sample_disbursement.transaction_type", "", "");
            //AppendNewRoleCode("sample_disbursement.transaction_type", "DMGD", "Returned Damaged");
            //AppendNewRoleCode("sample_disbursement.transaction_type", "DROP", "Sample Drop");
            //AppendNewRoleCode("sample_disbursement.transaction_type", "GAIN", "Increase Inventory");
            //AppendNewRoleCode("sample_disbursement.transaction_type", "LOSS", "Decrease Inventory");
            //AppendNewRoleCode("sample_disbursement.transaction_type", "LOST", "Lost In Transit");
            //AppendNewRoleCode("sample_disbursement.transaction_type", "OUTD", "Returned Outdated");
            //AppendNewRoleCode("sample_disbursement.transaction_type", "RETN", "Return");
            //AppendNewRoleCode("sample_disbursement.transaction_type", "SGAI", "System Corrective Gain");
            //AppendNewRoleCode("sample_disbursement.transaction_type", "SHIP", "Shipment Received");
            //AppendNewRoleCode("sample_disbursement.transaction_type", "SLOS", "System Corrective Loss");
            //AppendNewRoleCode("sample_disbursement.transaction_type", "THFT", "Theft");
            //AppendNewRoleCode("sample_disbursement.transaction_type", "TIN", "Transfer In");
            //AppendNewRoleCode("sample_disbursement.transaction_type", "TOUT", "Transfer Out");
            ////CreateDropDownCodeRole("sample_disbursement_request", "status_code", "sample_disbursement_request.status");
            //AddCodeRole("sample_disbursement_request.status", "", "");
            //AppendNewRoleCode("sample_disbursement_request.status", "REQU", "Requested");
            //AppendNewRoleCode("sample_disbursement_request.status", "SHIP", "Shipped");
            ////CreateDropDownCodeRole("call_presentation", "status_code", "call_presentation.status");
            //AddCodeRole("call_presentation.status", "", "");
            //AppendNewRoleCode("call_presentation.status", "ACTV", "Active");
            //AppendNewRoleCode("call_presentation.status", "INAC", "Inactive");
            ////CreateDropDownCodeRole("call_presentation", "reaction_type_code", "call_presentation.reaction_type");
            //AddCodeRole("call_presentation.reaction_type", "", "");
            //AppendNewRoleCode("call_presentation.reaction_type", "NEGA", "Negative");
            //AppendNewRoleCode("call_presentation.reaction_type", "NONE", "None");
            //AppendNewRoleCode("call_presentation.reaction_type", "POSI", "Positive");
            ////CreateDropDownCodeRole("call_presentation_detail", "reaction_type_code", "call_presentation_detail.reaction_type");
            //AddCodeRole("call_presentation_detail.reaction_type", "", "");
            //AppendNewRoleCode("call_presentation_detail.reaction_type", "NEGA", "Negative");
            //AppendNewRoleCode("call_presentation_detail.reaction_type", "NONE", "None");
            //AppendNewRoleCode("call_presentation_detail.reaction_type", "POSI", "Positive");

            #endregion

        }
    }
}
